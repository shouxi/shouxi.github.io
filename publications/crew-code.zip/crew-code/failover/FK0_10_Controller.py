
import numpy as np
from copy import deepcopy
import logging
LOGGER = logging.getLogger(__name__)
class Controller():
    TYPE = "CONTROLLER"
    _next_id = 1
    def _get_next_id():
        result = Controller._next_id
        Controller._next_id += 1
        return result

    def __init__(self, net,**params):
        super().__init__()

        self.id = Controller._get_next_id()
        self.job_id = self.id
        
        self.net = net
        self.net.controller=self
        # self.REDUCE_P=REDUCE_P
        # self.imp_non_blocking=IMP_NON_BLOCKING
        self.workers = {}

        """
            id ===> {w1, w3, w4, w5, ..., w13, w14,...}
            从1开始计数
            partial_reduce_cnt={
                1: [第 1 轮 partial reduce 节点] ,
                2: [第 2 轮 partial reduce 节点] ,
                3: [第 3 轮 partial reduce 节点] ,
                4: [第 4 轮 partial reduce 节点] ,
                ....
            }
        """
        self.partial_reduce_cnt={}
        self.waiting_group=[]

    # partial_reduce_members 表示参与这一轮partial reduce的节点编号, [2, 4, 5, 7, 8, 9]
    def register_partial_reduce(self,partial_reduce_members):

        idx=len(self.partial_reduce_cnt)+1
        self.partial_reduce_cnt[idx]=partial_reduce_members
        return idx


    def register_worker(self, worker):
        self.workers[worker.id] = worker

    # def join_waiting_group(self,new_worker_id):
    #     self.waiting_group.append(new_worker_id)
        
    #     LOGGER.info('Time {0}: worker {1} waiting group {2}  {3} is new worker'.format(self.net.get_cur_time(),self.id,self.waiting_group,new_worker_id))
    #     if len(self.waiting_group)==self.REDUCE_P:
    #         # p workers have completed training
            
    #         # first, inform group members to scatter
    #         # new_chunks=self.get_chunks_under_block(self.waiting_group)



    #         p_id=self.register_partial_reduce(deepcopy(self.waiting_group))
            
    #         np_partial_reduce_members=np.array(self.waiting_group)-1
    #         # 1. 所有节点要为 p_id 聚合与本地序号一致的分块, 同时将 P 组 worker 对应的 flag 置 1, 表示其已经属于某个 P 组
    #         for w in self.net.workers.values():
    #             w.full_time_partial_reduce_ids.append(p_id)
                
    #             members_flag=w.partial_reduce_member_flag[np_partial_reduce_members]
    #             assert not members_flag.any()  # 要求这些 worker 没有参与任何的 P 组, 全0 
    #             w.partial_reduce_member_flag[np_partial_reduce_members]=1

    #         # 2. 告知 partial_reduce_members 的成员, 它们组成了 P
    #         for member in self.waiting_group:
    #             self.net.workers[member].cur_partial_reduce_id=p_id
            
            

    #         # LOGGER.info('Time {0} non-blocking pid {1} {2}'.format(self.get_cur_time(),p_id,self.waiting_group))

    #         self.waiting_group.clear()

    #         self.net.check_link_status_when_P_determined(p_id) # 之前 pid=-1 的链路会被标记上正确的 pid
    #         if self.imp_non_blocking:
    #             self.net.non_blocking_rearrangement(p_id)
        


    # 为故障链路上的 REDUCE 流 重新寻找一个 backup worker
    # 为 p_id 组寻找一个 backup_worker 来聚合大小为 block_size 的 block_id 号分块
    def find_backup_for_reduce(self,p_id,block_id,block_size):
        backup_worker=-1
        
        partial_reduce_members=self.partial_reduce_cnt[p_id]
        
        # 从 list [1,3,4,5]  ===> np.array([0,2,3,4])
        np_partial_reduce_members=np.array(partial_reduce_members)-1
        
        '''
            available_conn_workers=[
                { 'dst_worker':w1, 'time_cost': [11, 13, 16, 11, 47, 11], 'max': 47 },
                { 'dst_worker':w2, 'time_cost': [21, 85, 12, 21, 25, 31], 'max': 85 },
                { 'dst_worker':w5, 'time_cost': [42, 23, 18, 71, 25, 41], 'max': 71 },
                { 'dst_worker':w7, 'time_cost': [26, 12, 10, 11, 65, 23], 'max': 65 },
                { 'dst_worker':w8, 'time_cost': [47, 15, 16, 31, 24, 23], 'max': 47 },
                { 'dst_worker':w9, 'time_cost': [39, 41, 10, 11, 65, 18], 'max': 65 },

            ]
        '''  
        available_conn_workers=[]
        
        for dst_worker in self.workers.keys():
            dst_worker_export_bw=self.net.bw[dst_worker-1]
            dst_worker_export_bw_for_p_members=dst_worker_export_bw[np_partial_reduce_members]
            
            # 1. 在全局中找到一个能够和 partial_reduce_members 通信的节点, 如果 dst_worker 到 partial_reduce_members 的带宽都不为0, 则这个 dst_worker 可用
            if dst_worker_export_bw_for_p_members.all():

                # 2. 统计每个 partial_reduce_member 到这个 worker 的未来一段时间的流量 traffic

                time_cost=[]
                for member in partial_reduce_members:
                    
                    traffic=0

                    # 2.1 member 的 全职聚合工作和兼职聚合工作, 在后续都有可能要发送数据给 dst_worker
                    aggregated_block_id_for_dst_worker=[]
                    dst_pid=self.workers[dst_worker].cur_partial_reduce_id
                    
                    # 全职
                    if dst_pid in self.workers[member].full_time_partial_reduce_ids:
                        aggregated_block_id_for_dst_worker.append(member)

                    """
                        part_time_aggregated_jobs={
                            pid :{  
                                    block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] },
                                    block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] }
                                }
                            pid :{  
                                block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                                block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                            }
                        }  
                    """
                    # 兼职
                    if dst_pid in self.workers[member].part_time_aggregated_jobs.keys():
                        for block_id,_ in self.workers[member].part_time_aggregated_jobs[dst_pid].items():
                            aggregated_block_id_for_dst_worker.append(block_id)
                    
                    
                    for block_id in aggregated_block_id_for_dst_worker:
                        if self.workers[dst_worker].block:
                            traffic=traffic+self.workers[dst_worker].under_blockmode_chunks_size[block_id-1]
                        else:
                            traffic=traffic+self.net.predefined_chunks_size[block_id-1]
                
                    # 2.2 查看转发表
                    for forward_task in self.workers[member].forward_broadcast_blocks_table:
                        if forward_task['dst_worker']==dst_worker:
                            traffic=traffic+forward_task['size']
                    
                    # 2.3 查看 link src--->dst 上还有多少数据量要发送
                    link=self.net.links[member-1][dst_worker-1]
                    for flow in link:
                        traffic=traffic+flow['left_size']
                    
                    traffic=traffic+block_size
                    time_cost.append(traffic/self.net.bw[member-1][dst_worker-1])
                
                available_conn_workers.append({'dst_worker':dst_worker,'time_cost':time_cost,'max':max(time_cost)})
        '''
            available_conn_workers=[
                { 'dst_worker':w1, 'time_cost': [11, 13, 16, 11, 47, 11], 'max': 47 },
                { 'dst_worker':w2, 'time_cost': [21, 85, 12, 21, 25, 31], 'max': 85 },
                { 'dst_worker':w5, 'time_cost': [42, 23, 18, 71, 25, 41], 'max': 71 },
                { 'dst_worker':w7, 'time_cost': [26, 12, 10, 11, 65, 23], 'max': 65 },
                { 'dst_worker':w8, 'time_cost': [47, 15, 16, 31, 24, 23], 'max': 47 },
                { 'dst_worker':w9, 'time_cost': [39, 41, 10, 11, 65, 18], 'max': 65 },

            ]
        '''  
        # 在 available_conn_workers 中找到 time_cost max 最小的 dst_worker 作为 backup_worker
        time_cost_max_list=[]
        for item in available_conn_workers:
            time_cost_max_list.append(item['max'])
        
        # time_cost_max_list =[47, 85, 71, 65, 47, 65] 有多个最小值就随机挑一个
        time_cost_max_list=np.array(time_cost_max_list)
        min_ids=np.where(time_cost_max_list==min(time_cost_max_list))[0]  # [0 4]
        idx=np.random.choice(min_ids)

        backup_worker=available_conn_workers[idx]['dst_worker']

        return backup_worker


    
    """
        partial_reduce_members (对应 p_id) 无法将大小为 block_size 的第 block_id 号分块发给 dst_worker
        将历史分块发送情况删除
        寻找 backup_worker, 在 backup_worker 节点上新建接收 part_time job, 在相应的链路上添加传输流
    """
    def failure_recovery_reduce(self,p_id,dst_worker,block_id,block_size,re_times):
        
        events=[]

        # 根据 partial reduce members 和 block_id = dst_worker寻找新的可用节点


        partial_reduce_members=self.partial_reduce_cnt[p_id]
        backup_worker=self.find_backup_for_reduce(p_id,block_id,block_size)

        if dst_worker==block_id:
            # 1. 消除 dst_worker 上 从 partial_reduce_members 上收到的 block_id 号 分块 以及 full_time_partial_reduce_ids 中的 pid, 表示不需要再为这个组聚合数据 ===> full_time_aggregated_blocks
            self.workers[dst_worker].erase_full_time_blocks_of_REDUCE(partial_reduce_members)
            self.workers[dst_worker].full_time_partial_reduce_ids.remove(p_id)
        else:
            # 1. 不是本职, 消除兼职工作上的收到的来自 pid 组的 blcok_id 块的信息  重新寻找节点的时候, 可能找回本来负责的节点, 此时要注意不要在本职节点上添加part_time_job
            self.workers[dst_worker].erase_part_time_aggregated_job(p_id,block_id)


        """
            part_time_aggregated_jobs={
                pid :{  
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] },
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] }
                    }
                pid :{  
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                }
            }  
        """

        
        assert backup_worker!=dst_worker
        
        '''
            2. 在 backup_worker 上添加 full_time_partial_reduce_ids 或者 part_time_aggregated_jobs  
            在 backup_worker 上添加 aggregated_jobs, 此时 backup_worker 可能就是负责聚合这个分块的本职节点, 此时应该在全职任务中添加这个聚合任务; 如果块号和节点序号不一样, 就是兼职 job
        '''
        if backup_worker!=block_id:  # 兼职工作
            if self.workers[backup_worker].part_time_aggregated_jobs.get(p_id,-1)==-1:
                self.workers[backup_worker].part_time_aggregated_jobs[p_id]={}
            self.workers[backup_worker].part_time_aggregated_jobs[p_id][block_id]={'arrival':np.zeros(len(self.workers),dtype=np.int_),'info':[{} for _ in range(len(self.workers))]}
        else:  # 极少数情况, 本职工作, 若块号为4, 节点号为4, 说明之前 4 号块发送给 4 号节点的时候链路失效了, 寻找了一个兼职节点负责聚合 4 号块, 现在兼职节点的链路失效了, 恰好 4 号节点链路又恢复了, 恰好又选中了 4 号节点聚合 4 号块
            self.workers[backup_worker].recover_full_time_jobs(p_id)

        # 3. 将 partial_reduce_members 到 dst_worker 的 p 条 links 上关于分块（块号为 block_id）的流 删除
        # 一定要先删除
        for src_worker in partial_reduce_members:
            link=self.net.links[src_worker-1][dst_worker-1]
            del_flow_id=None
            for id,flow in enumerate(link):
                if flow['flow_type'].split('-')[0]=='REDUCE' and flow['b_id']==block_id:
                    del_flow_id=id
                    break
            if del_flow_id is not None:
                del link[del_flow_id]
                

        # 4. partial_reduce_members 立即重新将 block_id 分块发给 backup_worker
        for w_id in partial_reduce_members:
            events.extend(self.workers[w_id].add_single_reduce_flow(backup_worker,p_id,block_id,block_size,re_times))
        
        return backup_worker
    '''
        link src--->dst 故障, src_worker 无法将大小为 block_size 的 b_id 号分块发送给 dst_worker, 正要发送数据的时候
        需要在 partial_reduce_members 中重新寻找一个节点, 将 b_id 号分块发送 dst_worker
    '''
    def failure_recovery_bcast(self,p_id,src_worker,dst_worker,b_id,block_size,aggregated_worker,re_times):
        # partial_reduce_members=self.partial_reduce_cnt[p_id]

        '''
            寻找新的 backup_worker 完成转发任务
        '''

        backup_worker=self.find_backup_for_bcast(p_id,dst_worker,b_id,block_size,aggregated_worker)


        assert backup_worker!=src_worker
        # 1. 要消除 src_worker 中的转发任务, 已经在别处完成, 没找到 啊 ？

        # 2. 在 backup_worker 中建立转发任务
        '''
            forward_broadcast_blocks_table=[
                {'p_id': 1, 'b_id": 4, 'size': 100, 'dst_worker': 3, 'aggregated_worker': 10 },
                {'p_id': 1, 'b_id": 2, 'size': 300, 'dst_worker': 5, 'aggregated_worker': 14 },
                {'p_id': 1, 'b_id": 8, 'size': 200, 'dst_worker': 3, 'aggregated_worker': 15 },
                {'p_id': 1, 'b_id": 1, 'size': 150, 'dst_worker': 9, 'aggregated_worker': 21 },

            ]
        '''
        new_forward={'p_id':p_id,'b_id':b_id,'size':block_size,'dst_worker':dst_worker,'aggregated_worker':aggregated_worker,'re_times':re_times}
        self.workers[backup_worker].forward_broadcast_blocks_table.append(new_forward)

        # 3. 立即让 backup_worker 检查是否已经收到了 b_id 号分块, 如果已经收到就马上转发出去; 没有则等收到再转发
        self.workers[backup_worker].check_forward_block(p_id,b_id,block_size,dst_worker,aggregated_worker,re_times)
        return backup_worker

    # aggregated_worker 表示这个分块是由哪个 worker 聚合的, block_size 没有用到, 也可以把 block_size 加到 traffic 上, 再求 time_cost
    # 在 p_id 中寻找一个 backup_worker, 将大小为 block_size 的 b_id 号分块发送给 dst_worker, 该分块之前由 aggregated_worker 完成聚合
    def find_backup_for_bcast(self,p_id,dst_worker,b_id,block_size,aggregated_worker):
        
        # 获得同组节点
        partial_reduce_members=self.partial_reduce_cnt[p_id]
        dst_pid=self.workers[dst_worker].cur_partial_reduce_id
        
        '''
            available_conn_workers=[
                {'src':w1, 'bw':100, 'traffic': 300, 'time_cost': 12 },
                {'src':w2, 'bw':200, 'traffic': 350, 'time_cost': 11 },
                {'src':w5, 'bw':150, 'traffic': 200, 'time_cost': 19 },
                {'src':w6, 'bw':550, 'traffic': 100, 'time_cost': 21 },
                {'src':w7, 'bw':100, 'traffic': 800, 'time_cost': 11 },
                {'src':w9, 'bw':100, 'traffic': 950, 'time_cost': 15 },
            ]
        '''
        available_conn_workers=[]

        for src_worker in partial_reduce_members:
            if src_worker==dst_worker:
                continue
            
            if self.net.bw[src_worker-1][dst_worker-1]!=0 and self.net.bw[aggregated_worker-1][src_worker-1]!=0:

                # 1. 首先找到能够与 dst_worker 通信的节点, 记录下它们到 dst_worker 的可用带宽
                available_conn_workers.append({'src':src_worker,'bw':self.net.bw[src_worker-1][dst_worker-1]})
        
                # 2. 确定 available worker 到 dst_worker 未来一段时间内需要传输的流量 traffic
                traffic=0

                # 2.1 src_worker 的 全职聚合工作和兼职聚合工作, 在后续都有可能要发送数据给 dst_worker
                aggregated_block_id_for_dst_worker=[]
                
                # 全职
                if dst_pid in self.workers[src_worker].full_time_partial_reduce_ids:
                    aggregated_block_id_for_dst_worker.append(src_worker)
                
                # 兼职
                if dst_pid in self.workers[src_worker].part_time_aggregated_jobs.keys():
                    for block_id,_ in self.workers[src_worker].part_time_aggregated_jobs[dst_pid].items():
                        aggregated_block_id_for_dst_worker.append(block_id)
                
                traffic=0
                for block_id in aggregated_block_id_for_dst_worker:
                    if self.workers[dst_worker].block:
                        traffic=traffic+self.workers[dst_worker].under_blockmode_chunks_size[block_id-1]
                    else:
                        traffic=traffic+self.net.predefined_chunks_size[block_id-1]

                # 2.2 查看转发表
                for forward_task in self.workers[src_worker].forward_broadcast_blocks_table:
                    if forward_task['dst_worker']==dst_worker:
                        traffic=traffic+forward_task['size']
                
                # 2.3 查看 link src--->dst 上还有多少数据量要发送
                link=self.net.links[src_worker-1][dst_worker-1]
                for flow in link:
                    traffic=traffic+flow['left_size']

                # 2.4 最后加上要转发的 b_id 分块的大小 block_size
                traffic=traffic+block_size  # 单位 KB
                # 计算这些流量的耗时
                time_cost=1000*8*traffic/(self.net.bw[src_worker-1][dst_worker-1]*1000000)   # KB/Mbps
                available_conn_workers[-1]['traffic']=traffic
                available_conn_workers[-1]['time_cost']=time_cost
        
        '''
            available_conn_workers=[
                { 'src':w8, 'bw':100, 'traffic': 300, 'time_cost': 11 },
                { 'src':w1, 'bw':100, 'traffic': 300, 'time_cost': 12 },
                { 'src':w2, 'bw':200, 'traffic': 350, 'time_cost': 11 },
                { 'src':w5, 'bw':150, 'traffic': 200, 'time_cost': 19 },
                { 'src':w6, 'bw':550, 'traffic': 100, 'time_cost': 21 },
                { 'src':w7, 'bw':100, 'traffic': 800, 'time_cost': 11 },
                { 'src':w9, 'bw':100, 'traffic': 950, 'time_cost': 15 },
            ]
        '''
        # 在 available_conn_workers 中找到 time_cost 最小的 worker 作为 backup_worker
        time_cost_list=[]
        for item in available_conn_workers:
            time_cost_list.append(item['time_cost'])
        
        # time_cost_list =[11,12, 11, 19, 21, 11, 15] 有多个最小值就随机挑一个
        time_cost_list=np.array(time_cost_list)
        min_ids=np.where(time_cost_list==min(time_cost_list))[0]  # [0 2 5]
        idx=np.random.choice(min_ids)

        backup_worker=available_conn_workers[idx]['src']

        return backup_worker
                
        
        