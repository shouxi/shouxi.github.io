import os
import json
import numpy as np
import random
# mkdir 'input/n=20/' in the dir where this scription exists


# to_Relay_or_Not_to_Relay_for_Inter-Cloud_Transfers.pdf
bw_values=np.array([
    117, 134, 182,  54,  70,  48,  46,  54,  58,  59,  78, 398,  80,  69,  53,  80,  64,  66,
    42,  64,  54, 173,  49,  26,  56,  38,  58,  32,  46,  29,  97,  83,  94,  79,  36,  52,
    50,  38,  64,  51,  44,  79,  80, 350,  54,  42,  46,  46,  48,  45,  37,  99, 107,  57,
    31,  76, 115,  93,  55,  45,  31,  93,  72,  40,  26,  76, 113,  93,  51,  28,  45,  64,
    58,  45,  44,  89, 172,  71,  87,  34,  42,  80,  77,  42,  35,  71,  82,  71,  48,  33,
    28,  33,  41,  67,  30,  20,  72,  84,  45,  22,  77,  69,  68,  64,  56,  48,  43,  32,
    36,  39
])


# Taming_Unbalanced_Training_Workloads_in_deep_Learning_with_Partial_Collective_Operations.pdf
train_time_distribution_1=[0.05, 0.054, 0.057, 0.061, 0.064, 0.068, 0.071, 0.075, 0.079, 0.082, 0.086, 0.09, 0.095, 0.101, 0.106, 0.111, 0.116, 0.122, 0.127, 0.132, 0.137, 0.142, 0.148, 0.153, 0.158, 0.163, 0.169, 0.174, 0.179, 0.184, 0.19, 0.195, 0.2]
train_time_probability_1=[0.062, 0.068, 0.002, 0.058, 0.079, 0.06, 0.009, 0.06, 0.027, 0.045, 0.044, 0.05, 0.071, 0.047, 0.035, 0.049, 0.041, 0.011, 0.028, 0.02, 0.031, 0.027, 0.02, 0.002, 0.01, 0.014, 0.003, 0.008, 0.008, 0.005, 0.003, 0.001, 0.002]


train_time_distribution_2=[0.05, 0.058, 0.067, 0.075, 0.083, 0.093, 0.104, 0.114, 0.125, 0.136, 0.146, 0.157, 0.168, 0.179, 0.189, 0.2]
train_time_probability_2=[0.002, 0.019, 0.181, 0.226, 0.221, 0.147, 0.062, 0.039, 0.022, 0.02, 0.024, 0.015, 0.01, 0.007, 0.003, 0.002]



train_time_distribution_3=[0.05, 0.062, 0.081, 0.101, 0.121, 0.141, 0.16, 0.18, 0.2]
train_time_probability_3=[0.782, 0.024, 0.029, 0.053, 0.029, 0.018, 0.012, 0.047, 0.006]

train_time_distribution_4=[0.01, 0.02]
train_time_probability_4=[0.9, 0.1]

train_time_distribution_5=[0.025, 0.03, 0.04, 0.05, 0.06, 0.08, 0.10, 0.12, 0.15]
train_time_probability_5=[0.12, 0.11, 0.15, 0.12, 0.1, 0.1, 0.1, 0.1, 0.1]


# 6 是将 2 的时间 [0.05, 0.2] 扩展到 [0.2, 0.4]
# 7 是将 2 的时间 [0.05, 0.2] 扩展到 [0.4, 0.6]
# 8 是将 2 的时间 [0.05, 0.2] 扩展到 [0.6, 0.8]
# 9 是将 2 的时间 [0.05, 0.2] 扩展到 [0.8, 1.0]
#10 是将 2 的时间 [0.05, 0.2] 扩展到 [1.0, 1.2]
train_time_distribution_6=[0.2, 0.211, 0.223, 0.233, 0.244, 0.257, 0.272, 0.285, 0.3, 0.315, 0.328, 0.343, 0.357, 0.372, 0.385, 0.4]
train_time_probability_6=[0.002, 0.019, 0.181, 0.226, 0.221, 0.147, 0.062, 0.039, 0.022, 0.02, 0.024, 0.015, 0.01, 0.007, 0.003, 0.002]

train_time_distribution_7=[0.4, 0.411, 0.423, 0.433, 0.444, 0.457, 0.472, 0.485, 0.5, 0.515, 0.528, 0.543, 0.557, 0.572, 0.585, 0.6]
train_time_probability_7=[0.002, 0.019, 0.181, 0.226, 0.221, 0.147, 0.062, 0.039, 0.022, 0.02, 0.024, 0.015, 0.01, 0.007, 0.003, 0.002]


train_time_distribution_8=[0.6, 0.611, 0.623, 0.633, 0.644, 0.657, 0.672, 0.685, 0.7, 0.715, 0.728, 0.743, 0.757, 0.772, 0.785, 0.8]
train_time_probability_8=[0.002, 0.019, 0.181, 0.226, 0.221, 0.147, 0.062, 0.039, 0.022, 0.02, 0.024, 0.015, 0.01, 0.007, 0.003, 0.002]

# train_time_distribution_9=[0.1]
# train_time_probability_9=[1]

train_time_distribution_9=[0.8, 0.811, 0.823, 0.833, 0.844, 0.857, 0.872, 0.885, 0.9, 0.915, 0.928, 0.943, 0.957, 0.972, 0.985, 1.0]
train_time_probability_9=[0.002, 0.019, 0.181, 0.226, 0.221, 0.147, 0.062, 0.039, 0.022, 0.02, 0.024, 0.015, 0.01, 0.007, 0.003, 0.002]

train_time_distribution_10=[1.0, 1.011, 1.023, 1.033, 1.044, 1.057, 1.072, 1.085, 1.1, 1.115, 1.128, 1.143, 1.157, 1.172, 1.185, 1.2]
train_time_probability_10=[0.002, 0.019, 0.181, 0.226, 0.221, 0.147, 0.062, 0.039, 0.022, 0.02, 0.024, 0.015, 0.01, 0.007, 0.003, 0.002]

train_time_distribution={
    1:[train_time_distribution_1,train_time_probability_1],
    2:[train_time_distribution_2,train_time_probability_2],
    3:[train_time_distribution_3,train_time_probability_3],
    4:[train_time_distribution_4,train_time_probability_4],
    5:[train_time_distribution_5,train_time_probability_5],
    6:[train_time_distribution_6,train_time_probability_6],
    7:[train_time_distribution_7,train_time_probability_7],
    8:[train_time_distribution_8,train_time_probability_8],
    9:[train_time_distribution_9,train_time_probability_9],
    10:[train_time_distribution_10,train_time_probability_10],
}


def generate_json_file(filepath,n,straggler_distribution,bandwidth_distribution):
    
    # filapath = /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce/input/n=10,sd=3,bwd=1/2.json
    path=os.path.dirname(filepath)   # /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce/input/n=10,sd=3,bwd=1

    # print(path)
    # input('pause')

    
    # make sure that the dir exists
    if not os.path.exists(path):
        os.makedirs(path)
    

    # generate bw array
    bw=np.zeros((n,n))

    assert bandwidth_distribution in [1,2,3]
    for i in range(n):
        for j in range(n):
            if bandwidth_distribution==1:
                bw[i][j] = min(max(1, int(np.random.normal(5, 1))),10)*25
            elif bandwidth_distribution==2:
                bw[i][j]=random.choice(bw_values)
            elif bandwidth_distribution==3:
                bw[i][j]=125


    # for i in range(n):
    #     for j in range(i):
    #         if bandwidth_distribution==1:
    #             bw[i][j] = min(max(1, int(np.random.normal(5, 1))),10)*25
    #             bw[j][i]=bw[i][j]
    #         else:
    #             bw[i][j]=random.choice(bw_values)
    #             bw[j][i]=bw[i][j]


    for i in range(n):
        bw[i][i]=np.inf

 
    # data={
    #     'bw':bw.tolist(),
    #     'worker1':[10,20,30,40,50],
    #     'worker2':[10,20,30,40,50],
    #     'worker3':[10,20,30,40,50],
    # }

    data={
        'bw':bw.tolist(),
    }


    
    # generate straggers
    
    for i in range(n):
        id=str(i+1)  # the workers id start from 1, 2, 3, ...,n
        name='worker'+id
        train_time_trace=[]
        for _ in range(200):  # obtain 200 rounds of training time
            train_time=np.random.choice(train_time_distribution[straggler_distribution][0], p=train_time_distribution[straggler_distribution][1])
            train_time_trace.append(train_time)
        data[name]=train_time_trace




    with open(filepath,'w') as f:
        json.dump(data,f,indent=4)
    
    print('{0} ===> has been generated'.format(filepath))
        

def generate_input_file(worker_num,straggler_distribution,bandwidth_distribution,trial_round):   
    
    # first get the abspath of the file
    # print(__file__)     # 使用 python3 generate_input.py  ===>  generate_input.py   使用 python3 test.py 间接调用这个脚本  ===>  /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce/generate_input.py
    
    # 但是无论直接调用还是间接调用, 下面的 script_abspath 和 script_dir 的结果都是一样的
    script_abspath=os.path.abspath(__file__)
    # print(script_abspath)     # /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce/generate_input.py
    
    # 本脚本文件的绝对目录
    script_dir=os.path.dirname(script_abspath)
    # print(script_dir)   # /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce
    
    
    relative_path='input/n='+str(worker_num)+',sd='+str(straggler_distribution)+',bwd='+str(bandwidth_distribution)  # 'input/n=20,sd=1,bwd=1'  sd:stragger_distribution, bwd:bandwidth_distribution
    abspath=os.path.join(script_dir,relative_path)
    
    # print(abspath)  # /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce/input/n=10,sd=3,bwd=1

    

    filename=str(trial_round)+'.json'  # '2.json'

    filepath=os.path.join(abspath,filename)

    # print(filepath)  # /home/newhome/ryw/dml-mininet/code/Inter-cloud-preduce/input/n=10,sd=3,bwd=1/2.json
    

    if not os.path.exists(filepath):
        print('{0} ===> not exists'.format(filepath))

        # generate the file
        generate_json_file(filepath,worker_num,straggler_distribution,bandwidth_distribution)
    
    else:
        print('{0} ===> has existed'.format(filepath))
    
    # read the json file input

    # with open(filepath) as f:
    #     inputdata=json.load(f)
    
    # print(inputdata)
    # print(type(inputdata))
    # print(type(inputdata.get('bw')))
    # print(inputdata.get('worker1'))
    # assert inputdata.get('worker1')
    # print('yes')


if __name__=='__main__':
    # for t in range(4):
    #     read_json_input(worker_num=10,straggler_distribution=1,trial_round=t+1)
    #     read_json_input(worker_num=10,straggler_distribution=2,trial_round=t+1)
    #     read_json_input(worker_num=10,straggler_distribution=3,trial_round=t+1)

    # 生成指定 带宽分布 和 straggler 分布 的文件, trial_round 表示 按照 前面指定的分布 第几次生成
    generate_input_file(worker_num=10,straggler_distribution=3,bandwidth_distribution=1,trial_round=2)