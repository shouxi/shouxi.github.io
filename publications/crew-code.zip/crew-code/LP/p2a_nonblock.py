import numpy as np

from mip import Model, xsum, minimize


def NodeBWBottleneck(BW, n, group):
    ai_S = np.zeros(n, dtype=np.int_)  # ingress
    bi_S = np.zeros(n, dtype=np.int_)  # egress

    BW = np.array(BW)
    group = np.array(group)
    group = group - 1
    for i in range(n):
        ai_S[i] = min(BW[:, i][group])
        bi_S[i] = min(BW[i, :][group])

    return ai_S, bi_S



def get_p2a_chunks_ByMIP_nonblock(bw,n,MODEL_SIZE,partial_reduce_member,non_block_sent_size):

    ai_S, bi_S = NodeBWBottleneck(bw, n, partial_reduce_member)
    m = Model("M")

    # add variables
    S = [m.add_var() for i in range(n)]  # repersent the chunks_size for nodes

    reduce_S = [m.add_var() for i in range(n)]

    X = m.add_var()
    Y = m.add_var()

    for i in range(n):
        for member in partial_reduce_member:
            m += reduce_S[i] >= (S[i] - non_block_sent_size[member - 1][i]) / bw[member - 1][i]
            m += reduce_S[i] >=0
            # m += reduce_S[i] >= max(S[i] - non_block_sent_size[member - 1][i],0) / bw[member - 1][i]

    for i in range(n):
        m += X >= reduce_S[i]
        m += Y >= S[i] / bi_S[i]


    m += xsum(S[i] for i in range(n)) == MODEL_SIZE

    m.objective = minimize(X + Y)       # represent the minimun complete time


    m.optimize()
    chunks_size=np.array([s.x for s in S])

    # input('sese')

    return chunks_size

