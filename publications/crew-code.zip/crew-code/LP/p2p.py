from mip import Model, xsum, minimize
import numpy as np

def NodeBWBottleneck(BW, n,p,group):

    assert p==len(group)
    BW=np.array(BW)
    group_bw=np.zeros((p,p))
    group=np.array(group)
    group=group-1
    for i,row in enumerate(group):
        for j,col in enumerate(group):
            group_bw[i][j]=BW[row][col]


    ai_S = np.zeros(p, dtype=np.int_)  # ingress
    bi_S = np.zeros(p, dtype=np.int_)  # egress

    for i in range(p):
        ai_S[i] = min(group_bw[:, i])
        bi_S[i] = min(group_bw[i, :])

    return ai_S, bi_S


def MIP_MODEL(ai_S, bi_S, p,MODEL_SIZE):
    m = Model("p2p_PS")

    # add variables
    S = [m.add_var() for i in range(p)]   # repersent the chunks_size for nodes

    X = m.add_var()
    Y = m.add_var()

    # create objective Function
    m.objective = minimize(X + Y)       # represent the minimun complete time

    # add constraints
    m += xsum(S[i] for i in range(p)) == MODEL_SIZE
    for i in range(p):
        m += X >= S[i] / ai_S[i]
        m += Y >= S[i] / bi_S[i]

    m.optimize()

    # return X.x + Y.x
    chunks_size=np.array([s.x for s in S])
    return chunks_size
        

def get_p2p_chunks_ByMIP(BW,n,p,MODEL_SIZE,group):  # group id from 1, 2, 3,..., n, BW id from 0, 1, 2,..., n-1, group i ===> bw i-1
    ai_S, bi_S = NodeBWBottleneck(BW, n,p,group)
    # print(ai_S)
    # print(bi_S)
    return MIP_MODEL(ai_S, bi_S, p,MODEL_SIZE)

def printf():
    print(__name__)

# if __name__=='__main__':
    # GetChunksByMIP(4)