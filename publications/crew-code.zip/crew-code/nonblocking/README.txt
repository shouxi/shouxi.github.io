比较 block 模式和 non-block 模式,
block 模式            is_block : True,     imp_non_blocking : False

non-block 模式        is_block : False,    imp_non_blocking : True