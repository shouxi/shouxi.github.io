# Example code files showcase the core designs of CREW. 

1. Networked-aware workload distribution with LP. 
2. FCFS flow scheduling. 
3. Failover schemes. 
4. Supports of non-blocking scatter. 