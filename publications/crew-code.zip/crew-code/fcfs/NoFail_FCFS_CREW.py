# Copyright Shouxi Luo & Renyi Wang
'''
    不允许出现 link failure
    改进了 non-blocking, 见论文算法2
'''



import heapq

import warnings
import numpy as np
import random
import json

import os,sys 
parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) 
sys.path.insert(0,parentdir)



import logging

from LP.a2a import get_a2a_chunks_ByMIP
from LP.p2a import get_p2a_chunks_ByMIP
from generate_input import generate_input_file
from NoFail_FCFS_Controller import Controller
from copy import deepcopy

import time
import logging
BASE_CHUNK_SIZE_KB=3000 #200000
# BASE_TRAIN_TIME=0.030
BASE_AGGREGATE_TIME=0.003


# def init_logging(filename):
#     # Create the logs directory
#     if not os.path.exists("./logs"):
#         os.mkdir("./logs")

#     # Init logging to file
#     logging.basicConfig(format='[%(asctime)s] [%(levelname)s] [%(name)s]  %(message)s',
#                         filename="./logs/%s" % filename,     
#                         filemode='w',
#                         level=logging.DEBUG,
#                         datefmt="%Y-%m-%d %H:%M:%S") 

# LOGGER = logging.getLogger(__name__)
# init_logging('CREW_ana'+'.log')

class Event(object):
    def __init__(self, t, obj, name, params={}):
        self.t = t
        self.obj = obj
        self.name = name
        self.params = params   # params 是 dict, e=Event(10,w,'complete_aggregate',{'p_id':1,'b_id':12,'size':100}), 那么 params = {'p_id': 1, 'b_id': 12, 'size': 100}
    
    def __lt__(self, other):
        return (self.t, self.obj.TYPE, self.name, self.obj) < (other.t, other.obj.TYPE,  other.name, other.obj)

    def exec(self):
        # print('# event debug', self.t,self.obj.TYPE,self.obj.id, self.name)
        # LOGGER.info('# event debug {0} {1} {2} {3}'.format(self.t,self.obj.TYPE,self.obj.id, self.name))
        return getattr(self.obj, self.name)(**self.params)        # 解包, 非字典形式
        

class EnvObject(object):
    UNDEFINED = 0
    STOPPED = -1
    def __init__(self):
        self.state = self.UNDEFINED
        self.env = None
    
    def register_env(self, env):
        self.env = env
    
    def get_cur_time(self):
        return self.env.get_cur_time()

    def start(self):
        return []

    def stop(self):
        self.state = self.STOPPED
        # LOGGER.info('{0} {1} STOP'.format(self.TYPE,self.id))
        return []

    def __lt__(self, other):
        return self.id < other.id

class Worker(EnvObject):
    IDLE = 1
    TRAINING = 2


    TYPE = "WORKER"
    _next_id = 1
    def _get_next_id():
        result = Worker._next_id
        Worker._next_id += 1
        return result

    def __init__(self, net,controller,worker_num,straggler_distribution,bandwidth_distribution,trial_round,REDUCE_P, model_size_KB=None,block=False,imp_non_blocking=True, grad_size_KB=None, name=None, **params):
        super().__init__()

        self.id = Worker._get_next_id()
        

        self.net=net
        self.controller=controller
        self.worker_num=worker_num
        self.straggler_distribution=straggler_distribution
        self.bandwidth_distribution=bandwidth_distribution
        self.trial_round=trial_round  # 重复实验轮次
        self.name = self.id or name
        self.REDUCE_P=REDUCE_P

        self.under_blockmode_chunks_size=None
        self.non_blocking_re_compute=None
        

        
        self.model_size_KB = model_size_KB
        self.grad_size_KB = grad_size_KB

        self.block=block
        self.imp_non_blocking=imp_non_blocking
        self.waiting_group=[] # just use for w1

        self.state = self.IDLE 
        self.train_round_cnt = 0
        self.sync_round_cnt = 0


        self.params = params
   
        self.net.register_worker(self)
        self.controller.register_worker(self)
        
        """
            由于 link breakdown, 需要帮助其他节点负责一个分块的聚合, 发生故障时, 由 controller 添加
            帮助 pid 组 聚合 block_id 分块, 数组表示接收情况, 长度为 n , 只有 pid 组内 的节点对应的序号才会置 1, 比如 pid 对应的 partial reduce members 为 {w1, w3, w4, w7, w8}, 那么 block_id 数组中只有下标为 {0,2,3,6,7} 的值 才会被置 1
            极端情况下, 可能要给 pid 组 聚合多个分块

        
            part_time_aggregated_jobs={
                pid :{  
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] },
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] }
                    }
                pid :{  
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                }
            }  
        
        """
        
        self.part_time_aggregated_jobs={}

        self.cur_partial_reduce_id=-1    # 表示节点目前正在参加的 partial reduce 的编号

        self.full_time_partial_reduce_ids=[]   # 当有 p 个 worker 就绪后, leader 就会广播这个 p_id, 该节点收到后就要为这 p 个节点聚合与自身序号一致的分块
        
        self.full_time_aggregated_blocks=np.zeros([self.worker_num],dtype=np.int_)  # [0 0 0 0 0 0 0 0 0]  full_time_aggregated_blocks[i] ===> worker i+1 这是 worker 本身的全职工作, 即聚合自身 id 号的分块, 比如 w4 需要接收来自所有节点的 4 号分块
        self.full_time_aggregated_blocks_info=[{} for _ in range(self.worker_num)] # [{},{},{},{},{},{},{},{},{}]
        
        # 对 non-blocking 的算法 2 改进会引起 worker 1 判断 P 的bug, 当 worker1 的分块增大时, 可能会重发 complement 流, 这 worker 1 会把补充流的发送者又列到一个新的 P 组里面, 此时需要多一轮的判断,
        # 当有一个 P 组形成的时候, 聚合节点除了在 partial_reduce_ids 中添加这个 P 组的 p_id 之外, 还要将 P 组中的 worker 对应的索引置 1 , 表示这个 worker 已经处于某个 P 中, 不能在加入到别的 P 中
        # 当 聚合节点完成对这个 P 组的聚合后, 要删除来自这个 P 组的接收缓存数据, 同时解除 P 组中所有成员的 flag 标记, 将其置 0;
        # 这样 worker 1 在判断 P 分组的时候, 由于 complement 流的到来, 会把 full_time_aggregated_blocks 位置1, 但是 flag 还是 1, 那么流的发送者就不会被添加到新的 P 组中去了
        self.partial_reduce_member_flag=np.zeros([self.worker_num],dtype=np.int_)
        

        # 指节点训练完成后, 将模型分成 n 个分块发送出去, 需要收到 n 个聚合后的结果, 与 cur_partial_reduce_id 一起
        self.arrival_aggregated_blocks=np.zeros([self.worker_num],dtype=np.int_)   # [0 0 0 0 0 0 0 0 0]  aggregated_blocks[i]  ===> worker i+1
        self.last_aggregate_task_endtime=0.0

        '''
            当前节点收到 arrival_aggregated_blocks 后, 可能需要将收到聚合过的分块 转发 给同组的其他 worker, 因为这个 worker 无法收到这个聚合的分块
            forward_broadcast_blocks_table=[
                {'p_id': 1, 'b_id": 4, 'size': 100, 'dst_worker': 3, 'aggregated_worker': 10 },
                {'p_id': 1, 'b_id": 2, 'size': 300, 'dst_worker': 5, 'aggregated_worker': 14 },
                {'p_id': 1, 'b_id": 8, 'size': 200, 'dst_worker': 3, 'aggregated_worker': 15 },
                {'p_id': 1, 'b_id": 1, 'size': 150, 'dst_worker': 9, 'aggregated_worker': 21 },

            ]
        '''
        self.forward_broadcast_blocks_table=[]  

        
        
        

        self.train_time_trace=[]
        self.init_train_time_trace()
    
    def init_train_time_trace(self):
        filepath='../input/'+'n='+str(self.worker_num)+',sd='+str(self.straggler_distribution)+',bwd='+str(self.bandwidth_distribution)+'/'+str(self.trial_round)+'.json'
        assert os.path.exists(filepath)
        with open(filepath) as f:
            data=json.load(f)
        
        worker_name='worker'+str(self.id)
        assert data.get(worker_name)
        self.train_time_trace.extend(data.get(worker_name))
    
    def get_training_time_cost(self):
        # self.get_training_time_cost=lambda:random.uniform(BASE_TRAIN_TIME*(1-0.1),BASE_TRAIN_TIME*(1+0.1))   # BASE_TRAIN_TIME=0.030  # fluctuations in 10%
        # for simplicity, discard train_time_trace[0]
        assert len(self.train_time_trace)>=self.train_round_cnt+1
        # return random.uniform(self.train_time_trace[self.train_round_cnt]*(1-0.1),self.train_time_trace[self.train_round_cnt]*(1+0.1))
        return self.train_time_trace[self.train_round_cnt]

    def get_aggregate_time_cost(self,chunk_size):

        # return chunk_size/BASE_CHUNK_SIZE_KB*BASE_AGGREGATE_TIME
        # return random.uniform(BASE_AGGREGATE_TIME*(1-0.1),BASE_AGGREGATE_TIME*(1+0.1))
        return BASE_AGGREGATE_TIME



    def start(self):
        return self.start_train()
    


    def start_train(self):
        if self.state == self.STOPPED:
            return []
        assert self.state!=self.TRAINING
        self.state=self.TRAINING
        self.train_round_cnt += 1

        cur_time=self.get_cur_time()
        t = cur_time + self.get_training_time_cost()
        # LOGGER.info('Time {0} Worker {1} starts TRAIN {2} SYNC {3} STATE {4}, end at {5}'.format(cur_time,self.id, self.train_round_cnt,self.sync_round_cnt,self.state,t))

        e = Event(t, self, 'complete_train')
        # print debug info
        #raise ValueError
        return [e, ]


    # worker complete train and turn to reduce
    def complete_train(self):

        cur_time=self.get_cur_time()
        # LOGGER.info('Time {0} Worker {1} completes TRAIN {2} SYNC {3} STATE {4}'.format(cur_time, self.id, self.train_round_cnt, self.sync_round_cnt, self.state))

        if self.state == self.STOPPED:
            return []
        
        self.state=self.IDLE

        if self.block:
            return self.net.workers[1].join_waiting_group(self.id)
        else:
            
            events=self.start_scatter()
            self.controller.join_waiting_group(self.id)
            return events
    
    # distribute chunks to n-1 workers
    def start_scatter(self,new_chunks=None):
  
        # cur_time=self.get_cur_time()
        # self.sync_round_cnt += 1
        # LOGGER.info('Time {0} Worker {1} starts REDUCE TRAIN {2} SYNC {3} STATE {4}'.format(cur_time, self.id,self.train_round_cnt, self.sync_round_cnt,self.state))
        # worker complete local train, begin to reduce directly without Controller and initialize the links id-->0, id-->1, id-->2, id-->3...
        events=[]
        worker_status={'TRAIN':self.train_round_cnt,'SYNC':self.sync_round_cnt,'SRC':self.id,'p_id':self.cur_partial_reduce_id}  # non-blocking 下是 -1

        if self.block:  # 说明是 blocking 模式
            assert new_chunks is not None
            self.under_blockmode_chunks_size=new_chunks
        
        events.extend(self.net.add_reduce_flows(self.id,worker_status))
        # LOGGER.info('{0} worker {1} start to scatter {2}'.format(self.get_cur_time(),self.id,self.train_round_cnt))

        return events        

    # worker complete reduce and turn to aggregate
    # maybe the group chunks recieved before, but just get the reduce task 
    def complete_group_reduce(self,p_id,b_id,block_size):  #   groupinfo {3:info, 4:info, 6:info, 7:info}
       
        return self.start_aggregate(p_id,b_id,block_size)
        

    def start_aggregate(self,p_id,b_id,block_size):
        if self.state == self.STOPPED:
            return []
        # assert self.state != self.AGGREGATE
        # self.state = self.AGGREGATE
        cur_time=self.get_cur_time()

      
        if self.last_aggregate_task_endtime>cur_time:   # there is a aggregate task running, can not interrupt
            t=self.last_aggregate_task_endtime+self.get_aggregate_time_cost(block_size)
        else:
            t=cur_time+self.get_aggregate_time_cost(block_size)
        
        self.last_aggregate_task_endtime=t

        # LOGGER.info('Time {0} Worker {1} starts AGGREGATE pid {2} end at {3}'.format(cur_time, self.id,p_id,t))
        e=Event(t,self,'complete_aggregate',{'p_id':p_id,'b_id':b_id,'size':block_size})

        return [e,]


    # worker complete train and turn to bcast
    def complete_aggregate(self,**block_info):  # 打包回字典  block_info : {'p_id':p_id,'b_id':b_id,'size':block_size}  哪个p, 哪一块, 块大小

        
        if self.state == self.STOPPED:
            return []
        
        

        # 清除完成的聚合任务, 包含本职和兼职
        p_id=block_info['p_id']
        b_id=block_info['b_id']

        # cur_time=self.get_cur_time()
        # LOGGER.info('Time {0} Worker {1} completes AGGREGATE p_id {2} block-id {3}  ===> start bcast'.format(cur_time, self.id, p_id,b_id))

        
        if self.id==b_id:      # 本职工作
            self.full_time_partial_reduce_ids.remove(p_id)
        else: # 兼职工作

            self.part_time_aggregated_jobs[p_id].pop(b_id)
            if len(self.part_time_aggregated_jobs[p_id])==0:
                self.part_time_aggregated_jobs.pop(p_id)

        events=self.start_bcast(block_info)

        return events

    def start_bcast(self,block_info):
        # assert self.state == self.AGGREGATE
        # self.state=self.BCAST
        

       
        # worker complete aggregate, begin to bcast directly without Controller and initialize the links id-->0, id-->1, id-->2, id-->3...
        events=[]
        # LOGGER.info('{0} worker {1} start to bcast {2} {3}'.format(self.get_cur_time(),self.id,group_info.keys(),group_info))
        events.extend(self.net.add_bcast_flows(self.id,block_info))  #   block_info : {'p_id':p_id,'b_id':b_id,'size':block_size}  哪个p, 哪一块, 块大小

        return events    

    # other workers aggregate the chunks and sent them all back
    def get_all_blocks_back(self):
        # assert self.state==self.BCAST
        # cur_time=self.get_cur_time()
        # LOGGER.info('Time {0} worker {1} complete P REDUCE (finish BCAST task) TRAIN {2} SYNC {3} '.format(cur_time,self.id,self.train_round_cnt,self.sync_round_cnt))
        # LOGGER.info('{0} worker {1} complete bcast TRAIN {2} '.format(self.get_cur_time(),self.id,self.train_round_cnt))
        self.sync_round_cnt += 1
        return self.start_train()

    
    # take action when a flow arrivals, info : {'size':80}, 如果是 bcast 流, 还需要包含 aggregated_worker, 表示这个 block 之前是哪个 worker 聚合的
    def add_arrival_flow_toBuffer(self,src_workerid,flow_type,partial_reduce_id,block_id,info):
        assert flow_type.split('-')[0]=='REDUCE' or flow_type.split('-')[0]=='BCAST'
        # cur_time=self.get_cur_time()

        """
            part_time_aggregated_jobs={
                pid :{  
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] },
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] }
                    }
                pid :{  
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                }
            }  
        """

        if flow_type.split('-')[0]=='REDUCE':
            if block_id==self.id: #  说明是自己负责的分块, 比如 w4 负责 block4, 本职工作不需要检查 partial_reduce_id
                
                assert self.full_time_aggregated_blocks[src_workerid-1]==0
                self.full_time_aggregated_blocks[src_workerid-1]=1
                assert len(self.full_time_aggregated_blocks_info[src_workerid-1])==0
                self.full_time_aggregated_blocks_info[src_workerid-1].update(info)     # 代码检查, info 的作用, 目前 info 只包含 'size'
                
                # LOGGER.info('Time {0} worker {1}(self-pid {2}) recv from worker {3} flow_type {4} ( p-id {5} b-id{6}  block_size {7} )'.format(self.get_cur_time(),self.id,self.cur_partial_reduce_id,src_workerid,flow_type,partial_reduce_id,block_id,info['size']))
                # LOGGER.info('Time {0} worekr {1} get reduce flow from {2} segment {3}'.format(cur_time,self.id,src_workerid,info['DST']))  # src_workerid and segment are arranged from 1, 2, 3, 4,...
            
            else:  # 不是自己的分块, 应该核对self.part_time_aggregated_job 是否有对应的任务
                pids=self.part_time_aggregated_jobs.keys()
                assert partial_reduce_id in pids   
                assert block_id in self.part_time_aggregated_jobs[partial_reduce_id].keys()  # 确保需要为该分块聚合
                partial_reduce_members=self.controller.partial_reduce_cnt[partial_reduce_id]
                assert src_workerid in partial_reduce_members  # 确保发送节点在 P 中
                assert self.part_time_aggregated_jobs[partial_reduce_id][block_id]['arrival'][src_workerid-1]==0
                self.part_time_aggregated_jobs[partial_reduce_id][block_id]['arrival'][src_workerid-1]=1

                assert len(self.part_time_aggregated_jobs[partial_reduce_id][block_id]['info'][src_workerid-1])==0
                self.part_time_aggregated_jobs[partial_reduce_id][block_id]['info'][src_workerid-1].update(info)
                # LOGGER.info('Time {0} worker {1}(pid{2}) recv from worker {3} PART-TIME REDUCE b-id {4}(pid{5})    part_time_aggregated_blocks {6}'.format(self.get_cur_time(),self.id,self.cur_partial_reduce_id,src_workerid,block_id,partial_reduce_id,self.part_time_aggregated_jobs[partial_reduce_id][block_id]['arrival']))
                

        else:  # BCAST
            assert self.arrival_aggregated_blocks[block_id-1]==0 and partial_reduce_id==self.cur_partial_reduce_id
            # 有待改进, non-blocking 下 rearrangement
            if self.block:
                block_size=self.under_blockmode_chunks_size[block_id-1]
            elif self.imp_non_blocking:
                block_size=self.non_blocking_re_compute[block_id-1]
            else:
                block_size=self.net.predefined_chunks_size[block_id-1]

            assert abs(block_size-info['size'])<1e-9
            self.arrival_aggregated_blocks[block_id-1]=1

            # 查看是否需要将收到的 broadcast aggregated block 转发给同组的其他节点
            self.check_forward_table(partial_reduce_id,block_id,info['size'],info['aggregated_worker'])
            # LOGGER.info('Time {0} worker {1}(self-pid {2}) recv from worker {3} flow_type {4} ( p-id {5} b-id{6}  block_size {7} )'.format(self.get_cur_time(),self.id,self.cur_partial_reduce_id,src_workerid,flow_type,partial_reduce_id,block_id,info['size']))
    
    # check self.full_time_partial_reduce_ids' task is statisfied or not, self.full_time_aggregated_blocks represent the arrival reduce data chunks
    def check_reduce_flows(self):
        
        # make sure self.full_time_aggregated_blocks only consist of 0 or 1
        assert np.array_equal(self.full_time_aggregated_blocks, self.full_time_aggregated_blocks.astype(bool))
        
        """
            self.full_time_partial_reduce_ids=[2, 3]
            controller.partial_reduce_cnt={
                1: [第 1 轮 partial reduce 节点] ,
                2: [第 2 轮 partial reduce 节点] ,
                3: [第 3 轮 partial reduce 节点] ,
                4: [第 4 轮 partial reduce 节点] ,
                ....
            }
        """

        events=[]
        # full_time_collect_all_blocks_pid=[]  
        
        # 首先查看本职工作完成了哪些, 本地的 self.full_time_partial_reduce_ids 是本地需要聚合的组, 查看哪些组已经收齐了
        
        for p_id in self.full_time_partial_reduce_ids:
            # 1. 获得该 p_id 的 参与成员
            
            partial_reduce_members=self.controller.partial_reduce_cnt[p_id]
            

            # 2. 查看参与成员的分块是否已经发送到本地
            np_partial_reduce_members=np.array(partial_reduce_members,dtype=np.int_)
            np_partial_reduce_members=np_partial_reduce_members-1
            recv_blocks=self.full_time_aggregated_blocks[np_partial_reduce_members]
            
            # 收齐了参与成员的所有分块
            if recv_blocks.all():
                # full_time_collect_all_blocks_pid.append(p_id)

                # 将该组的接收缓存和对应的信息清空

                """
                        self.full_time_aggregated_blocks=np.zeros([self.worker_num],dtype=np.int_)  # [0 0 0 0 0 0 0 0 0]  full_time_aggregated_blocks[i] ===> worker i+1 这是 worker 本身的全职工作, 即聚合自身 id 号的分块
                        self.full_time_aggregated_blocks_info=[{} for _ in range(self.worker_num)]
                """
                
                self.full_time_aggregated_blocks[np_partial_reduce_members]=0
                
                # 同时清空这些 参与成员的 flag 信息, 不在属于某个 P 组
                flag_info=self.partial_reduce_member_flag[np_partial_reduce_members]
             
                assert flag_info.all()
                self.partial_reduce_member_flag[np_partial_reduce_members]=0


                blocks_size=[]
                for src in np_partial_reduce_members:
                    blocks_size.append(self.full_time_aggregated_blocks_info[src]['size'])
                    self.full_time_aggregated_blocks_info[src].clear()
                
                # if len(set(blocks_size))!=1:
                #     print(blocks_size)
                np_blocks_size=np.round(blocks_size,6)
                assert len(set(np_blocks_size))==1
                # 对该组接收到的分块进行聚合处理
                # LOGGER.info('Time {0} worker {1} FULL-TIME collect blocks {2} from pid-{3} {4}'.format(self.get_cur_time(), self.id,self.id,p_id,partial_reduce_members))
                events.extend(self.complete_group_reduce(p_id,self.id,blocks_size[0]))

        # 清空已经完成的本职工作的 p_id, 改成 complete_aggregated 再删除
        # for p_id in full_time_collect_all_blocks_pid:
        #     self.full_time_partial_reduce_ids.remove(p_id)

        
        # 接着处理兼职工作, 查看 self.part_time_aggregated_jobs 的完成情况
        """
            part_time_aggregated_jobs={
                pid :{  
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] },
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] }
                    }
                pid :{  
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                }
            }  
        """
       
        for p_id in self.part_time_aggregated_jobs:
            jobs=self.part_time_aggregated_jobs[p_id]

            # 获得参与 p_id 的成员
            partial_reduce_members=self.controller.partial_reduce_cnt[p_id]
            np_partial_reduce_members=np.array(partial_reduce_members,dtype=np.int_)
            np_partial_reduce_members=np_partial_reduce_members-1

            # 可能为这个 p_id 兼职聚合多个分块
            for b_id,recv_buffer in jobs.items():

                recv_blocks=recv_buffer['arrival'][np_partial_reduce_members]
                if recv_blocks.all():
                    blocks_size=[]
                    for src in np_partial_reduce_members:
                        blocks_size.append(recv_buffer['info'][src]['size'])

                    assert len(set(blocks_size))==1
                    recv_buffer['arrival'][np_partial_reduce_members]=0
                    # LOGGER.info('Time {0} worker {1} PART-TIME collect blocks {2} from {3}'.format(self.get_cur_time(), self.id,b_id,partial_reduce_members))
                    events.extend(self.complete_group_reduce(p_id,b_id,blocks_size[0]))
                    
        
        # 清除工作放在 complete_aggregate 的地方完成

        # 消除已经完成的 part_time_jobs
        # for p_id,b_id in part_time_collect_all_blocks_pid_bid:
        #     self.part_time_aggregated_jobs[p_id].pop(b_id)
        
        # 清空没有分块要聚合的 p_id
        # no_job_pids=[]
        # for p_id in self.part_time_aggregated_jobs:
        #     if len(self.part_time_aggregated_jobs[p_id])==0:
        #         no_job_pids.append(p_id)
        # for p_id in no_job_pids:
        #     self.part_time_aggregated_jobs.pop(p_id)
                
        return events
    
    def check_bcast_flows(self):
        # make sure self.arrival_aggregated_blocks only consist of 0 or 1
        assert np.array_equal(self.arrival_aggregated_blocks, self.arrival_aggregated_blocks.astype(bool))

        events=[]
        if self.arrival_aggregated_blocks.all():  # the worker get all blocks aggregated
            # LOGGER.info('Time {0} worker {1} get all blocks {2} ready to next round training'.format(self.get_cur_time(), self.id,self.arrival_aggregated_blocks))
            events.extend(self.get_all_blocks_back())
            self.arrival_aggregated_blocks[:]=0  # set zero 
            self.cur_partial_reduce_id=-1
        
        return events


    # non-blocking for w1    
    def generate_reduce_group(self):

        # make sure self.full_time_aggregated_blocks only consist of 0 or 1
        assert np.array_equal(self.full_time_aggregated_blocks, self.full_time_aggregated_blocks.astype(bool))

        reduce_groups=[]
        '''
            reduce_groups=
            [
                [1,2,3,5],
                [6,7,8,10]
            ]
        '''
        group=[]
        
        for src,v in enumerate(self.full_time_aggregated_blocks):
            if v==1 and self.partial_reduce_member_flag[src]==0:
                group.append(src+1)
                if len(group)==self.REDUCE_P:
                    reduce_groups.append(deepcopy(group))
                    group.clear()
        
        # if len(reduce_groups)>0:
        #     LOGGER.info('worker {0} generate reduce groups {1}'.format(self.id,reduce_groups))

        return reduce_groups
    

    # block for w1
    def join_waiting_group(self,new_worker_id):
        self.waiting_group.append(new_worker_id)
        
        # LOGGER.info('Time {0} Blokcing MODE worker {1} waiting group {2}  {3} is new worker'.format(self.get_cur_time(),self.id,self.waiting_group,new_worker_id))
        events=[]
        if len(self.waiting_group)==self.REDUCE_P:
            # p workers have completed training
            
            # first, inform group members to scatter
            new_chunks=self.get_chunks_under_block(self.waiting_group)
            # LOGGER.info('Time {0} reach P'.format(self.get_cur_time()))
            # LOGGER.info('Blocking mode blocks_size {0}'.format(new_chunks))

            p_id=self.controller.register_partial_reduce(deepcopy(self.waiting_group))
            

            # 1. 所有节点要为 p_id 聚合与本地序号一致的分块, 同时将 P 组 worker 对应的 flag 置 1, 表示其已经属于某个 P 组
            for w in self.net.workers.values():
                w.full_time_partial_reduce_ids.append(p_id)
                np_partial_reduce_members=np.array(self.waiting_group)-1
                members_flag=w.partial_reduce_member_flag[np_partial_reduce_members]
                assert not members_flag.any()  # 要求这些 worker 没有参与任何的 P 组, 全0 
                w.partial_reduce_member_flag[np_partial_reduce_members]=1

            # 2. 告知 partial_reduce_members 的成员, 它们组成了 P
            for member in self.waiting_group:
                self.net.workers[member].cur_partial_reduce_id=p_id
                      

            for id in self.waiting_group:
                events.extend(self.net.workers[id].start_scatter(new_chunks))
            
            self.waiting_group.clear()
            self.net.check_link_status_when_P_determined(p_id)

            

        
        return events

    def get_chunks_under_block(self,worker_group):   # worker_group 的节点编号从 1 开始
        if self.net.model_split=='network-aware':

            chunks_size=get_p2a_chunks_ByMIP(self.net.bw,self.worker_num,self.model_size_KB,worker_group)
            return chunks_size
        else:
            chunks_size=np.array([self.model_size_KB/self.worker_num]*self.worker_num)
            return chunks_size

    """
        以下代码用于故障恢复
    """
    # 由于链路故障, 导致 worker 不再承担原有的任务, 比如 w4 负责 block4, 现在不负责了, 需要把来自partial_reduce_members的block4清空
    def erase_full_time_blocks_of_REDUCE(self,partial_reduce_members):
        # partial_reduce_members 的编号从 1 开始, 而 full_time_aggregated_blocks 数组下标从 0 开始
        for w_id in partial_reduce_members:
            self.full_time_aggregated_blocks[w_id-1]=0
            self.full_time_aggregated_blocks_info[w_id-1].clear()


    def add_single_reduce_flow(self,dst_worker,p_id,block_id,block_size):  # dst_worker, block_id从 1 开始
        
        assert p_id==self.cur_partial_reduce_id
        
        if self.block:
            chunk_size=self.under_blockmode_chunks_size[block_id-1]
        else:
            chunk_size=self.net.predefined_chunks_size[block_id-1]
        
        assert chunk_size==block_size
        worker_status={'TRAIN':self.train_round_cnt,'SYNC':self.sync_round_cnt,'SRC':self.id,'p_id':self.cur_partial_reduce_id}
        return self.net.add_single_reduce_flow(self.id,dst_worker,chunk_size,block_id,worker_status)

    # 此时节点负责非自身编号分块的聚合, 但是由于链路发生故障, 需要终止这个 part time job 的聚合, 结束这个兼职聚合工作
    def erase_part_time_aggregated_job(self,p_id,block_id):

        """
            part_time_aggregated_jobs={
                pid :{  
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] },
                        block_id: { arrival: [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info:[ {}, {}, {} ] }
                    }
                pid :{  
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                    block_id: { arrival : [0, 0, 0, 0, 0,... , 0, 0, 0, 0], info : [ {}, {}, {} ] },
                }
            }  
        """
        assert p_id in self.part_time_aggregated_jobs.keys()
        block_ids=self.part_time_aggregated_jobs[p_id].keys()
        assert block_id in block_ids
        self.part_time_aggregated_job[p_id].pop(block_id)
        if len(self.part_time_aggregated_jobs[p_id])==0:
            self.part_time_aggregated_jobs.pop(p_id)
        
    
    # 极少数情况, 若块号为4, 节点号为4, 说明之前 4 号块发送给 4 号节点的时候链路失效了, 寻找了一个兼职节点负责聚合 4 号块, 现在兼职节点的链路失效了, 恰好 4 号节点链路又恢复了, 恰好又选中了 4 号节点聚合 4 号块
    def recover_full_time_jobs(self,p_id):
        partial_reduce_members=self.controller.partial_reduce_cnt[p_id]
        np_partial_reduce_members=np.array(partial_reduce_members,dtype=np.int_)
        np_partial_reduce_members=np_partial_reduce_members-1
        recv_blocks=self.full_time_aggregated_blocks[np_partial_reduce_members]
        
        assert not recv_blocks.any()  # 要求全0
        for idx in np_partial_reduce_members:
            assert len(self.full_time_aggregated_blocks_info[idx])==0
        
        assert p_id not in self.full_time_partial_reduce_ids
        self.full_time_partial_reduce_ids.append(p_id)
    
    def check_forward_table(self,p_id,b_id,block_size,block_aggregated_worker):
        '''
            当前节点收到 arrival_aggregated_blocks 后, 可能需要将收到聚合过的分块 转发 给同组的其他 worker, 因为这个 worker 无法收到这个聚合的分块
            forward_broadcast_blocks_table=[
                {'p_id': 1, 'b_id": 4, 'size': 100, 'dst_worker': 3, 'aggregated_worker': 10 },
                {'p_id': 1, 'b_id": 2, 'size': 300, 'dst_worker': 5, 'aggregated_worker': 14 },
                {'p_id': 1, 'b_id": 8, 'size': 200, 'dst_worker': 3, 'aggregated_worker': 15 },
                {'p_id': 1, 'b_id": 1, 'size': 150, 'dst_worker': 9, 'aggregated_worker': 21 },

            ]
        '''
        del_forward_id=[]
        for idx,f_task in enumerate(self.forward_broadcast_blocks_table):
            if f_task['b_id']==b_id:
                dst_worker=f_task['dst_worker']
                
                src_worker=self.id
                assert block_size==f_task['size']
                # 转发前检查 link src ---> dst 是否正常 
                if self.net.bw[src_worker-1][dst_worker-1]!=0:  # link OK, 可以转发
                    self.net.add_single_bcast_flow(src_worker,dst_worker,p_id,b_id,block_size,f_task['aggregated_worker']) 
                else: # link 失效, 让别的节点完成转发任务
                    assert block_aggregated_worker==f_task['aggregated_worker']
                    backup_worker=self.controller.failure_recovery_bcast(p_id,src_worker,dst_worker,b_id,block_size,f_task['aggregated_worker'])
                    # LOGGER.info('Time {0} link {1} ---> {2} FAIL BCAST p-id {3} b-id {4} forward backup_worker {5}'.format(self.get_cur_time(),src_worker,dst_worker,p_id,block_id,backup_worker))
                del_forward_id.append(idx)
        
        # 将处理过的 forward task 消除
        del_forward_id.sort(reverse=True)
        for id in del_forward_id:
            del self.forward_broadcast_blocks_table[id]


    
    def check_forward_block(self,p_id,b_id,block_size,dst_worker,aggregated_worker):
        if self.state==2: # 说明早就已经收到 b_id 的分块, 并且节点已经开始下一轮的训练了
            assert self.cur_partial_reduce_id==-1
            # 转发分块, 虽然节点开始进入下一轮训练, 我们默认它还存储着历史的模型
            self.net.add_single_bcast_flow(self.id,dst_worker,p_id,b_id,block_size,aggregated_worker)

            # 删除转发任务
            assert self.forward_broadcast_blocks_table[-1]['p_id']==p_id and self.forward_broadcast_blocks_table[-1]['b_id']==b_id and self.forward_broadcast_blocks_table[-1]['dst_worker']==dst_worker
            self.forward_broadcast_blocks_table.pop()

        elif self.arrival_aggregated_blocks[b_id-1]==1: # 已经收到 b_id 的分块, 但是还在等待其他分块
            assert self.cur_partial_reduce_id==p_id
            # 转发分块
            self.net.add_single_bcast_flow(self.id,dst_worker,p_id,b_id,block_size,aggregated_worker)
            
            # 删除转发任务
            assert self.forward_broadcast_blocks_table[-1]['p_id']==p_id and self.forward_broadcast_blocks_table[-1]['b_id']==b_id and self.forward_broadcast_blocks_table[-1]['dst_worker']==dst_worker
            self.forward_broadcast_blocks_table.pop()
        else:
            # 没收到分块, 什么都不做
            pass

                           


        
            

        


class Network(EnvObject):
    RUNNING = 2
    TYPE = 'Network'
    def __init__(self, time_step=1e-3,net_mode='FIFO',model_split='network-aware',**params):
        super().__init__()
        self.time_step = time_step
        assert net_mode in ['FS' ,'FIFO','PRIOR'] and model_split in ['network-aware' ,'evenly-divided']
        self.net_mode=net_mode
        self.model_split=model_split
        self.controller=None



    def start(self):
        assert self.state != self.RUNNING
        self.state = self.RUNNING

        return self.process()

    def check_active_flows(self):
        return []

    
    def process(self):
        if self.state == self.STOPPED:
            return []
        events = self.check_active_flows()
        
        t = self.get_cur_time() + self.time_step
        e = Event(t, self, 'process')
        events.append(e)
        return events
    



class OBSNET(Network):

    _next_id = 1
    def _get_next_id():
        result = OBSNET._next_id
        OBSNET._next_id += 1
        return result

    def __init__(self,worker_num=10,straggler_distribution=1,bandwidth_distribution=1,trial_round=1, time_step=1e-3,net_mode='FIFO',model_split='network-aware', bw_kbps=1e6,model_size_KB=1e3):
        super().__init__(time_step=time_step,net_mode=net_mode,model_split=model_split, bw_kbps=bw_kbps)

        self.bw_kbps = bw_kbps
        self.worker_num=worker_num
        self.straggler_distribution=straggler_distribution
        self.bandwidth_distribution=bandwidth_distribution
        self.trial_round=trial_round

        self.model_size_KB=model_size_KB
        self.id=OBSNET._get_next_id()
        self.flow_last_update_time=0.0
        self.workers={}
        
        '''
            修改了流结构, 比 FMReduce 复杂     worker 在发送流的时候, 要符合现在的格式, 还有 net  process   check_active_flows 的时候, 也要匹配现在的流格式  代码检查
            partial reduce id 和 block id 都是从 1 开始
            self.links=
            [
                [ [ {'left_size':70,'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            links[i][j] means the link from src=i+1--->dst=j+1 , 可能有多条 flows
        '''
        # initialize the flows


        self.links=[[[] for i in range(self.worker_num)] for j in range(self.worker_num)]


        # self.bw=np.zeros([worker_num,worker_num],dtype=np.float)
        # # initialize the bw 
        # # bw[i][j] means bandwidth (i+1--->j+1) src=i+1, dst=j+1
        # for i in range(worker_num):
        #     for j in range(worker_num):
        #         # self.bw[i][j]=random.uniform(self.bw_kbps*(1-self.net_fluctuation),self.bw_kbps*(1+self.net_fluctuation))
        #         bw = min(max(1, int(np.random.normal(5, 1))),10)
        #         self.bw[i][j]=bw*250000

                
        
        # for i in range(worker_num):
        #     self.bw[i][i]=np.inf

        self.bw=None
        self.init_bw()
        # LOGGER.info('\n{0}'.format(self.bw))
        
        # print(self.bw)  type(bw) = numpy.ndarray      type(bw[0]) = numpy.ndarray
        # [
        # [inf  4.  3.  6.  5.  4.  6.  6.  5.  4.]
        # [ 5. inf  5.  6.  3.  3.  7.  6.  5.  4.]
        # [ 5.  5. inf  4.  5.  6.  5.  6.  4.  3.]
        # [ 3.  6.  4. inf  5.  5.  3.  4.  4.  5.]
        # [ 3.  4.  3.  6. inf  6.  5.  6.  4.  6.]
        # [ 4.  5.  4.  4.  3. inf  5.  3.  3.  3.]
        # [ 4.  5.  4.  5.  6.  6. inf  4.  4.  5.]
        # [ 6.  5.  6.  3.  4.  4.  5. inf  4.  6.]
        # [ 4.  3.  4.  5.  5.  5.  5.  6. inf  5.]
        # [ 4.  6.  5.  5.  4.  4.  5.  5.  5. inf]
        # ] 

        
        # chunks_size [1968.57189564 1968.56503259 1998.95333687 2064.963367   1998.9463679 ]
        if self.model_split=='evenly-divided':
            self.predefined_chunks_size=np.array([self.model_size_KB/self.worker_num]*self.worker_num)
        elif self.model_split=='network-aware':
            
            self.predefined_chunks_size=get_a2a_chunks_ByMIP(self.bw,self.worker_num,self.model_size_KB)   # bug for big bw???
            # LOGGER.info('predefined blocks size {0}'.format(self.predefined_chunks_size))

        '''
            记录网络中失效的链路, link 一旦 breakdown, 双向都会失效
            设定最多允许 p-1 条
            self.failure_links={
                (2,3) : 原始带宽,
                (4,9) : 原始带宽,
                (6,7) : 原始带宽,
                ...
            }
            下标从 0 开始
            (2,3): 表示节点 worker 3 到 worker 4 的链路
        '''
        self.failure_links={}
           



    def register_worker(self, worker):
        self.workers[worker.id] = worker

    def init_bw(self):
        filepath='../input/'+'n='+str(self.worker_num)+',sd='+str(self.straggler_distribution)+',bwd='+str(self.bandwidth_distribution)+'/'+str(self.trial_round)+'.json'
        assert os.path.exists(filepath)
        with open(filepath) as f:
            data=json.load(f)
        assert data.get('bw')
        self.bw=np.array(data.get('bw'))



    
    def get_chunks_size(self,workerid,conn_type,reflash=False):

        # chunks_size [1968.57189564 1968.56503259 1998.95333687 2064.963367   1998.9463679 ]
        if reflash:  # if network changes, but this is wrong way
        
            self.predefined_chunks_size=get_a2a_chunks_ByMIP(self.bw,self.worker_num,self.model_size_KB)  # wrong wrong wrong
        
        assert conn_type=='REDUCE' or conn_type=='BCAST'
        if conn_type=='REDUCE':
            return self.predefined_chunks_size
        else:
            mychunk_size=self.predefined_chunks_size[workerid-1]
            return mychunk_size

    
    
    def check_active_flows(self):  # check check check123 !!!

        events=[]
        cur_time=self.get_cur_time()

        assert not cur_time<self.flow_last_update_time

        if cur_time<=self.flow_last_update_time:
            return []

        # note that worker id arrange from 1, 2, 3, 4...

        # 开始对流的通信数据量进行处理

        '''
            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
        '''

        for src in range(self.worker_num):
            for dst in range(self.worker_num):
                flows=self.links[src][dst]             # 改成links!!!
                if len(flows)==0:
                    continue

                flow_nums=len(flows)
                # assert len_bef<=2
                
                # 计算这段时间这条链路允许通过的数据量
                done_KB=1000000*self.bw[src][dst]*(cur_time-self.flow_last_update_time)/8/1000   # bw[i][j]=42Mbps
                
        
                if self.net_mode=='FS':  # 公平分配
                    
                    each_flow_done_KB=done_KB/flow_nums
                    completed_flows={}
                    completed_flows_id=[]

                    '''
                        completed_flows={
                            flow1 : {'src_worker' : w1, 'flow_type' : REDUCE , 'p_id' : 3, 'b_id' : 1, 'info':{ 'size':100, 'aggregated_worker':w3 } },
                            flow2 : {'src_worker' : w2, 'flow_type' : REDUCE , 'p_id' : 3, 'b_id' : 4, 'info':{ 'size':300, 'aggregated_worker':w8 } },
                            flow3 : {'src_worker' : w5, 'flow_type' : BCAST  , 'p_id' : 1, 'b_id' : 2, 'info':{ 'size':140, 'aggregated_worker':w3 } },
                            flow5 : {'src_worker' : w1, 'flow_type' : REDUCE , 'p_id' : 8, 'b_id' : 4, 'info':{ 'size':200, 'aggregated_worker':w1 } },
                        }
                        completed_flows_id=[ flow1, flow2, flow3, flow5 ]
                    '''

                    for id,flow in enumerate(flows):
                        left_size=flow['left_size']  # left_size 单位 KB
                        
                        if left_size<=each_flow_done_KB:  # 说明这条流已经传输完成, 虽然 each_flow_done_KB 超出了 left_size, 超出的部分可以给同 link 的其他 flow 使用, 但是这样代码太复杂, 且超出部分很少, 可以忽略不计 42000000*0.001/8/1000 = 5.4 KB, 分给每条流的数据量就更少了

                            info={'size':flow['total_size']}
                            if 'aggregated_worker' in flow:
                                info['aggregated_worker']=flow['aggregated_worker']
                            
                            completed_flows[id]={'src_worker':src+1, 'dst_worker':dst+1,'flow_type':flow['flow_type'], 'p_id':flow['p_id'], 'b_id':flow['b_id'], 'info':info}
                            completed_flows_id.append(id)
                        else:  # 没有完成, 则更新剩余大小 left_size
                            flow['left_size']=left_size-each_flow_done_KB
                    
                    # 先清除所有已经完成的流, 再把这些清除了的流的到达的消息告知 dst_worker
                    completed_flows_id.sort(reverse=True)  # 倒序删除
                    for id in completed_flows_id:
                        del flows[id]
                    
     

                    
                    # 告知 dst_worker 流到达的消息
                    for k,v in completed_flows.items():
                        self.workers[dst+1].add_arrival_flow_toBuffer(v['src_worker'],v['flow_type'],v['p_id'],v['b_id'],v['info'])
                      
                                                           
                elif self.net_mode=='FIFO':

                    '''
                        self.links=
                        [
                            [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                            [ [], [], [], [], [] ],
                            [ [], [], [], [], [] ],
                            [ [], [], [], [], [] ],
                            [ [], [], [], [], [] ],
                        ]
                    '''
                    warnings.simplefilter('error')  # can delete
                    remain_KB=-done_KB
                    completed_flows={}
                    completed_flows_id=[]

                    '''
                        completed_flows={
                            flow1 : {'src_worker' : w1, 'flow_type' : REDUCE , 'p_id' : 3, 'b_id' : 1, 'info':{ 'size':100, 'aggregated_worker':w3 } },
                            flow2 : {'src_worker' : w2, 'flow_type' : REDUCE , 'p_id' : 3, 'b_id' : 4, 'info':{ 'size':300, 'aggregated_worker':w8 } },
                            flow3 : {'src_worker' : w5, 'flow_type' : BCAST  , 'p_id' : 1, 'b_id' : 2, 'info':{ 'size':140, 'aggregated_worker':w3 } },
                            flow5 : {'src_worker' : w1, 'flow_type' : REDUCE , 'p_id' : 8, 'b_id' : 4, 'info':{ 'size':200, 'aggregated_worker':w1 } },
                        }
                        completed_flows_id=[ flow1, flow2, flow3, flow5 ]
                    '''
                    for id, flow in enumerate(flows):
                        remain_KB=flow['left_size']+remain_KB
                        if remain_KB<=0:
                            info={'size':flow['total_size']}
                            if 'aggregated_worker' in flow:
                                info['aggregated_worker']=flow['aggregated_worker']
                            completed_flows[id]={'src_worker':src+1, 'flow_type':flow['flow_type'], 'p_id':flow['p_id'], 'b_id':flow['b_id'], 'info':info}
                            completed_flows_id.append(id)
                        else:
                            flow['left_size']=remain_KB
                            break

                    # 先清除所有已经完成的流, 再把这些清除了的流的到达的消息告知 dst_worker
                    completed_flows_id.sort(reverse=True)  # 倒序删除
                    for id in completed_flows_id:
                        del flows[id]

        
                    # if len(completed_flows)!=0:
                    #     print(self.get_cur_time())
                    #     print(flows)
                    #     print('---------------------')
                    
                    # 告知 dst_worker 流到达的消息
                    for k,v in completed_flows.items():
                        
                        self.workers[dst+1].add_arrival_flow_toBuffer(v['src_worker'],v['flow_type'],v['p_id'],v['b_id'],v['info'])
                        # LOGGER.info('Time {0} worker {1}(pid{2}) recv from worker {3} b-id {4}(pid{5})    full_time_aggregated_blocks {6}'.format(cur_time,dst+1,self.workers[dst+1].cur_partial_reduce_id,src+1,v['b_id'],v['p_id'],self.workers[dst+1].full_time_aggregated_blocks))
                                   
                    # len_aft=len(flows)
                    # if len_bef-len_aft>=2:
                    #     LOGGER.info('Extreme phenomenon 0 ===> {0} flows complete'.format(len_bef-len_aft))
                elif self.net_mode=='PRIOR':
                    p_list=[]

                    '''
                        [   
                            [   2,  'reduce',    4], 
                            [   2,  'bcast',   2], 
                            [   4,  'reduce',   0], 
                            [   4,  'reduce',   1], 
                            [   9,  'reduce',   3], 
                            [   -1, 'reduce',  5]
                        ]
                    '''

                    for id,flow in enumerate(flows):
                        if flow['p_id']!=-1:
                            p_list.append([flow['p_id'],flow['flow_type'],id])
                    # p_list=sorted(p_list, key=lambda x:(x[0],x[1][4].lower()))
                    p_list=sorted(p_list, key=lambda x:(x[1][4].lower()))
                    count=0
                    for id,flow in enumerate(flows):
                        if flow['p_id']==-1:
                            p_list.append([flow['p_id'],flow['flow_type'],id])
                            count=count+1
                    assert count==1 or count==0
                    # print(p_list)

                    
                    remain_KB=-done_KB
                    completed_flows={}
                    completed_flows_id=[]

                    '''
                        completed_flows={
                            flow1 : {'src_worker' : w1, 'flow_type' : REDUCE , 'p_id' : 3, 'b_id' : 1, 'info':{ 'size':100, 'aggregated_worker':w3 } },
                            flow2 : {'src_worker' : w2, 'flow_type' : REDUCE , 'p_id' : 3, 'b_id' : 4, 'info':{ 'size':300, 'aggregated_worker':w8 } },
                            flow3 : {'src_worker' : w5, 'flow_type' : BCAST  , 'p_id' : 1, 'b_id' : 2, 'info':{ 'size':140, 'aggregated_worker':w3 } },
                            flow5 : {'src_worker' : w1, 'flow_type' : REDUCE , 'p_id' : 8, 'b_id' : 4, 'info':{ 'size':200, 'aggregated_worker':w1 } },
                        }
                        completed_flows_id=[ flow1, flow2, flow3, flow5 ]
                    '''
                    for item in p_list:
                        id=item[-1]
                        remain_KB=flows[id]['left_size']+remain_KB
                        if remain_KB<=0:
                            info={'size':flows[id]['total_size']}
                            if 'aggregated_worker' in flows[id]:
                                info['aggregated_worker']=flows[id]['aggregated_worker']
                            completed_flows[id]={'src_worker':src+1, 'flow_type':flows[id]['flow_type'], 'p_id':flows[id]['p_id'], 'b_id':flows[id]['b_id'], 'info':info}
                            completed_flows_id.append(id)
                        else:
                            flows[id]['left_size']=remain_KB
                            break

                    # 先清除所有已经完成的流, 再把这些清除了的流的到达的消息告知 dst_worker
                    completed_flows_id.sort(reverse=True)  # 倒序删除
                    for id in completed_flows_id:
                        del flows[id]

        
                    # if len(completed_flows)!=0:
                    #     print(self.get_cur_time())
                    #     print(flows)
                    #     print('---------------------')
                    
                    # 告知 dst_worker 流到达的消息
                    for k,v in completed_flows.items():
                        
                        self.workers[dst+1].add_arrival_flow_toBuffer(v['src_worker'],v['flow_type'],v['p_id'],v['b_id'],v['info'])
                        # LOGGER.info('Time {0} worker {1}(pid{2}) recv from worker {3} b-id {4}(pid{5})    full_time_aggregated_blocks {6}'.format(cur_time,dst+1,self.workers[dst+1].cur_partial_reduce_id,src+1,v['b_id'],v['p_id'],self.workers[dst+1].full_time_aggregated_blocks))
                                   
                    # len_aft=len(flows)
                    # if len_bef-len_aft>=2:
                    #     LOGGER.info('Extreme phenomenon 0 ===> {0} flows complete'.format(len_bef-len_aft))

        
        self.flow_last_update_time=cur_time


        '''
            记录网络中失效的链路, link 一旦 breakdown, 双向都会失效
            设定最多允许 p-1 条
            self.failure_links={
                (2,3) : 原始带宽,
                (3,2) : 原始带宽,
                (4,9) : 原始带宽,
                (9,4) : 原始带宽,
                ...
            }
            下标从 0 开始
            (2,3): 表示节点 worker 3 到 worker 4 的链路
        '''

        # 以一定概率发生network failures, 一次只有2条 ( 双向 link 都断 ), 目前先不要断 w1 的链路, w1 是 leader 
        if len(self.failure_links)<0:
            n=self.worker_num

            # worker a, b 从 1 开始, 目前 worker 1 不能坏
            worker_a=random.randint(2,n)
            worker_b=random.randint(2,n)

            """
                (rand_row, rand_col)=(3,4) 表示 w4<--->w5 的链路失效 
            """

            is_breakdown=np.random.choice(a=[0,1],p=[0.9,0.1])  # 0.1 的概率 链路失效
            if worker_a!=worker_b and is_breakdown:  # 双向带宽都会清0
                
                self.failure_links[(worker_a-1,worker_b-1)]=self.bw[worker_a-1][worker_b-1]  # 检查单位!!!!!!!!!  代码检查
                self.bw[worker_a-1][worker_b-1]=0

                self.failure_links[(worker_b-1,worker_a-1)]=self.bw[worker_b-1][worker_a-1]
                self.bw[worker_b-1][worker_a-1]=0
  
                # 处理 breakdown 的链路上的流       events 多余了
                events.extend(self.link_failure_recovery(worker_a,worker_b))




        # if self.workers[1].block:
        #     pass
        # else:
        #     '''
        #         worker id_minimum check the arrival reduce flows, if arrival number >= p, than add reduce tasks and assign the tasks to other workers
        #     '''
        #     # get the worker with minimum id
        #     min_id=min(self.workers.keys())  # min_id=1
        #     p_reduce_generate_worker=self.workers[min_id]
        #     reduce_groups=p_reduce_generate_worker.generate_reduce_group()
        #     '''
        #         reduce_groups=
        #         [
        #             [1,2,3,5],
        #             [6,7,8,10]
        #         ]

        #         worker.full_time_partial_reduce_ids= [ p_id_1, p_id_2, p_id_3, ..., p_id_10 ]        
        #     '''

        #     # 生成 p 的时候要检查网络 link 有没有损坏
        #     # 这个时候所有的 partial_reduce_members 都是按照节点序号发送分块, 节点号和分块号一一对应
           
        #     for partial_reduce_members in reduce_groups:           # rrrrr
        #         p_id=self.controller.register_partial_reduce(partial_reduce_members)
        #         np_partial_reduce_members=np.array(partial_reduce_members)-1
                
        #         # 所有节点要为 p_id 聚合与本地序号一致的分块, 同时将 P 组 worker 对应的 flag 置 1, 表示其已经属于某个 P 组
        #         for w in self.workers.values():
        #             w.full_time_partial_reduce_ids.append(p_id)
        #             members_flag=w.partial_reduce_member_flag[np_partial_reduce_members]
        #             assert not members_flag.any()  # 要求这些 worker 没有参与任何的 P 组, 全 0
        #             w.partial_reduce_member_flag[np_partial_reduce_members]=1
                
        #         # 告知 partial_reduce_members 的成员, 它们组成了 P
        #         for member in partial_reduce_members:
        #             self.workers[member].cur_partial_reduce_id=p_id
                
        #         LOGGER.info('Time {0} non-blocking pid {1} {2}'.format(self.get_cur_time(),p_id,partial_reduce_members))
        #         self.check_link_status_when_P_determined(p_id) # 之前 pid=-1 的链路会被标记上正确的 pid
                
        #         self.non_blocking_rearrangement(p_id)


        # check REDUCE and BCAST tasks
        
        for w in self.workers.values():
            events.extend(w.check_reduce_flows())
            events.extend(w.check_bcast_flows())

        return events

    # 在 non-block 模式下, 无等待直接 scatter, 当 p 确定的时候, 需要重新针对这 p 个节点的 scatter 进行检查, 是否遇到 fail link
    # 在 block 模式下, 先确定 p, 为了和 non-block 统一, 我们让 p 个节点先发数据, 然后检查涉及的 link, 是否 fail
    def check_link_status_when_P_determined(self,p_id):
        partial_reduce_members=self.controller.partial_reduce_cnt[p_id]
        # 依次检查 partial_reduce_members 到 w1, w2, w3, ... , wn 的 link 有没有故障
        for dst_worker in np.arange(len(self.workers))+1:
            isbreak=False
            block_id=-1
            block_size=0
            for src_worker in partial_reduce_members:

                # 1. 首先检查 dst_worker 是否已经收到了 src_worker 发送的分块, 该分块号和 dst_worker 编号一致
                if self.workers[dst_worker].full_time_aggregated_blocks[src_worker-1]==1:  # 说明分块已经发送完了, 不需要管 link 是否失效
                    continue

                # 2. 在 link 上找到分块对应的那条流, 检查这条 link 是否正常, 正常: 为这条流添加 p_id; 失效, 启动故障恢复
                link=self.links[src_worker-1][dst_worker-1]
                full_time_job_flow=None
                for flow in link:
                    if flow['flow_type'].split('-')[0]=='REDUCE' and flow['b_id']==dst_worker:
                        full_time_job_flow=flow
                        break
                # print(src_worker,dst_worker)
                assert full_time_job_flow is not None
                if self.bw[src_worker-1][dst_worker-1]==0: # link 失效, 重传, 寻找 backup_worker
                    isbreak=True
                    block_id=full_time_job_flow['b_id']
                    block_size=full_time_job_flow['total_size']
                    break
                else:
                    if not self.workers[src_worker].block:
                        assert full_time_job_flow['p_id']==-1
                        full_time_job_flow['p_id']=p_id
                    else:
                        assert full_time_job_flow['p_id']==p_id


            if isbreak:
                assert dst_worker==block_id
                backup_worker=self.controller.failure_recovery_reduce(p_id,dst_worker,block_id,block_size)
                # LOGGER.info('Time {0} link {1} ---> {2} FAIL REDUCE p-id {3} b-id {4} aggregated backup_worker {5}'.format(self.get_cur_time(),src_worker,dst_worker,p_id,block_id,backup_worker))


    def get_rearrangement_chunks_under_non_block(self,worker_group):   # worker_group 的节点编号从 1 开始
        if self.model_split=='network-aware':

            chunks_size=get_p2a_chunks_ByMIP(self.bw,self.worker_num,self.model_size_KB,worker_group)
            return chunks_size
        else:
            chunks_size=np.array([self.model_size_KB/self.worker_num]*self.worker_num)
            return chunks_size

    # 暂时不考虑 link failure       
    def non_blocking_rearrangement(self,p_id):
        assert not self.workers[1].block
        partial_reduce_members=self.controller.partial_reduce_cnt[p_id]

        # 根据 p 的组成, 获得精确的 blocks size
        re_blocks_size=self.get_rearrangement_chunks_under_non_block(partial_reduce_members)
        # LOGGER.info('Time {0} Non-Blocking ===> Rearrangement'.format(self.get_cur_time()))
        # LOGGER.info('pid-{0} p-members {1} NEW BLOCK SIZE {2}'.format(p_id,partial_reduce_members,re_blocks_size))

        for member in partial_reduce_members:
            self.workers[member].non_blocking_re_compute=re_blocks_size
        self.re_blocks_size=re_blocks_size

        for dst_worker in np.arange(len(self.workers))+1:
            delta=re_blocks_size[dst_worker-1]-self.predefined_chunks_size[dst_worker-1]


            '''
                    self.full_time_partial_reduce_ids=[]   # 当有 p 个 worker 就绪后, leader 就会广播这个 p_id, 该节点收到后就要为这 p 个节点聚合与自身序号一致的分块
                    
                    self.full_time_aggregated_blocks=np.zeros([self.worker_num],dtype=np.int_)  # [0 0 0 0 0 0 0 0 0]  full_time_aggregated_blocks[i] ===> worker i+1 这是 worker 本身的全职工作, 即聚合自身 id 号的分块, 比如 w4 需要接收来自所有节点的 4 号分块
                    self.full_time_aggregated_blocks_info=[{} for _ in range(self.worker_num)] # [{},{},{},{},{},{},{},{},{}]
               
                    self.links=
                    [
                        [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                        [ [], [], [], [], [] ],
                        [ [], [], [], [], [] ],
                        [ [], [], [], [], [] ],
                        [ [], [], [], [], [] ],
                    ]         
            '''


            if delta>0:  # 说明 dst_worker 之前负责的 block 要增大
                # LOGGER.info('Time {0} {1} 发送给 dst {2} 从 {3} 增大到 {4} 增大 {5}'.format(self.get_cur_time(),partial_reduce_members,dst_worker,self.predefined_chunks_size[dst_worker-1],re_blocks_size[dst_worker-1],delta))
                for src_worker in partial_reduce_members:
                    # 先查看 src ---> dst 的link, 是否有(reduce, bid=dst_worker, pid=p_id)的流
                    link=self.links[src_worker-1][dst_worker-1]
                    full_time_reduce_job_id=-1
                    for id,flow in enumerate(link):
                        flow_type=flow['flow_type']
                        pid=flow['p_id']
                        bid=flow['b_id']
                        if flow_type.split('-')[0]=='REDUCE' and pid==p_id and bid==dst_worker:
                            full_time_reduce_job_id=id
                            break

                    # 如果之前的流还在发送, 修改流的 total_size 和 left_size
                    if full_time_reduce_job_id!=-1:
                        assert self.workers[dst_worker].full_time_aggregated_blocks[src_worker-1]==0
                        # LOGGER.info('Time {0} src_worker {1} 发送给 dst_worker {2} 还在发送中...left_size {3} total_size {4}'.format(self.get_cur_time(),src_worker,dst_worker,link[full_time_reduce_job_id]['left_size'],link[full_time_reduce_job_id]['total_size']))
                        
                        link[full_time_reduce_job_id]['left_size']=link[full_time_reduce_job_id]['left_size']+delta
                        link[full_time_reduce_job_id]['total_size']=link[full_time_reduce_job_id]['total_size']+delta
                        # LOGGER.info('修改后: left_size {0} total_size {1}'.format(link[full_time_reduce_job_id]['left_size'],link[full_time_reduce_job_id]['total_size']))

                    else:
                        # 之前的流已经发送完了, 那么 dst_worker 上应该收到了 block, 需要将其清空, 然后补充一条流, 大小为 delta 的数据量
                        assert self.workers[dst_worker].full_time_aggregated_blocks[src_worker-1]==1
                        # LOGGER.info('Time {0} src_worker {1} 发送给 dst_worker {2} 发送完成...dst_worker 已经接收, 需要补充大小为 {3} 的流'.format(self.get_cur_time(),src_worker,dst_worker,delta))
                        self.workers[dst_worker].full_time_aggregated_blocks[src_worker-1]=0
                        self.workers[dst_worker].full_time_aggregated_blocks_info[src_worker-1].clear()
                        # 注意发送补充流的时候, left_size = delta, total_size = re_blocks_size[dst_worker-1]
                        # LOGGER.info('清空 dst_worker {0} 的接收信息 '.format(dst_worker))
                        self.add_single_reduce_complement_flow(src_worker,dst_worker,delta,re_blocks_size[dst_worker-1],dst_worker)
            elif delta<0:
                # 说明 dst_worker 负责的 block 应该减小
                # LOGGER.info('Time {0} {1} 发送给 dst {2} 从 {3} 减小到 {4} 减小 {5}'.format(self.get_cur_time(),partial_reduce_members,dst_worker,self.predefined_chunks_size[dst_worker-1],re_blocks_size[dst_worker-1],delta))
                for src_worker in partial_reduce_members:
                    # 先查看 src ---> dst 的link, 是否有(reduce, bid=dst_worker, pid=p_id)的流
                    link=self.links[src_worker-1][dst_worker-1]
                    full_time_reduce_job_id=-1
                    for id,flow in enumerate(link):
                        flow_type=flow['flow_type']
                        pid=flow['p_id']
                        bid=flow['b_id']
                        if flow_type.split('-')[0]=='REDUCE' and pid==p_id and bid==dst_worker:
                            full_time_reduce_job_id=id
                            break                    
                    # 如果之前的流还在发送, 修改流的 total_size 和 left_size
                    if full_time_reduce_job_id !=-1:
                        assert self.workers[dst_worker].full_time_aggregated_blocks[src_worker-1]==0
                        # LOGGER.info('Time {0} src_worker {1} 发送给 dst_worker {2} 还在发送中...left_size {3} total_size {4}'.format(self.get_cur_time(),src_worker,dst_worker,link[full_time_reduce_job_id]['left_size'],link[full_time_reduce_job_id]['total_size']))
                        link[full_time_reduce_job_id]['left_size']=link[full_time_reduce_job_id]['left_size']+delta
                        link[full_time_reduce_job_id]['total_size']=link[full_time_reduce_job_id]['total_size']+delta

                        if link[full_time_reduce_job_id]['left_size']<=0:  # 说明此时按照新的分块大小, 达到了发送量

                            # LOGGER.info('将还在发送的的 left_size 减去 delta {0}, 发现 left_size = {1} 小于 000'.format(delta,link[full_time_reduce_job_id]['left_size']))
                            info={'size':link[full_time_reduce_job_id]['total_size']}
                            if 'aggregated_worker' in link[full_time_reduce_job_id]:
                                info['aggregated_worker']=link[full_time_reduce_job_id]['aggregated_worker']
                            
                            v={'src_worker':src_worker, 'flow_type':link[full_time_reduce_job_id]['flow_type'], 'p_id':link[full_time_reduce_job_id]['p_id'], 'b_id':link[full_time_reduce_job_id]['b_id'], 'info':info}

                            # 先清除完成的流, 再把这条流的到达的消息告知 dst_worker
                            del link[full_time_reduce_job_id]
                            # LOGGER.info('清除这条流, 告诉 dst_worker {0} 流已到达'.format(dst_worker))
                            self.workers[dst_worker].add_arrival_flow_toBuffer(v['src_worker'],v['flow_type'],v['p_id'],v['b_id'],v['info'])
                        # else:
                            # LOGGER.info('将还在发送的的 left_size 减去 delta {0}, 发现 left_size = {1} 大于 000, 不需要任何操作'.format(delta,link[full_time_reduce_job_id]['left_size']))
                    

                    else:
                        # 之前的流已经发送完了, 那么 dst_worker 上应该收到了 block, 此时不需要任何操作, dst_worker 象征性的把多收到的数据丢弃即可, 注意要修改info 里面的size 信息
                        assert self.workers[dst_worker].full_time_aggregated_blocks[src_worker-1]==1
                        # LOGGER.info('dst_worker {0} 在 rearrangement 之前已经收完了 flow, 虽然流的 size 减小了, 此时不需要任何操作'.format(dst_worker))
                        self.workers[dst_worker].full_time_aggregated_blocks_info[src_worker-1]['size']=re_blocks_size[dst_worker-1]





    # workerid: data source
    def add_reduce_flows(self,workerid,worker_status):
        
        events=[]
        # check the flows first
        events.extend(self.check_active_flows())  # 凡是往网络中修改网络流的操作, 都应该将网络流状态更新到当前
        cur_time=self.get_cur_time()

        '''

            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            
            # datasize:
            # chunks[0]: id--->1
            # chunks[1]: id--->2
            # ...
            # chunks[n-1]: id--->n
        
        '''
        if self.workers[1].block:
            chunks=self.workers[workerid].under_blockmode_chunks_size
        else:
            chunks=self.get_chunks_size(workerid,'REDUCE')
        worker_export_links=self.links[workerid-1]

        
        # worker_status={'TRAIN':self.train_round_cnt,'SYNC':self.sync_round_cnt,'SRC':self.id,'p_id':self.cur_partial_reduce_id}

        for dst,link in enumerate(worker_export_links):

            new_flow=deepcopy(worker_status)
            new_flow['left_size']=chunks[dst]   # 单位 KB
            new_flow['total_size']=chunks[dst]  # 单位 KB
            new_flow['flow_type']='REDUCE'
            new_flow['b_id']=dst+1   # b_id 从 1 开始
     
            # assert len(link) in [0,1]
            # if len(link)==1:
            #     assert link[0]['flow_type']=='BCAST'
            
            # link.insert(0,new_flow)

            link.append(new_flow)
           
            
            # LOGGER.debug('Time {0} src = {1} dst = {2} pid {3} type {4} left_size {5} total_size {6}'.format(cur_time,workerid,dst+1,new_flow['p_id'],new_flow['flow_type'],new_flow['left_size'],new_flow['total_size'],new_flow['total_size']))

        
        assert self.flow_last_update_time==cur_time
        # check_active_flows() already make them equal, but the meanings are different
        # check_active_flows() makes the exist flows update to cur_time
        # add_reduce_flows() set the new flows time to cur_time
        self.flow_last_update_time=cur_time

        return events

    # workerid: data source
    def add_bcast_flows(self,src_worker,block_info):  #   block_info : {'p_id':p_id,'b_id':b_id,'size':block_size}  哪个p, 哪一块, 块大小
        
        events=[]
        # check the flows first
        events.extend(self.check_active_flows())  # 凡是往网络中修改网络流的操作, 都应该将网络流状态更新到当前
        cur_time=self.get_cur_time()

        '''
            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            
            # datasize:
            # chunks[0]: id--->1
            # chunks[1]: id--->2
            # ...
            # chunks[n-1]: id--->n
        
        '''

        p_id=block_info['p_id']
        b_id=block_info['b_id']
        block_size=block_info['size']
        links=self.links[src_worker-1]
        partial_reduce_members=self.controller.partial_reduce_cnt[p_id]

        for dst_worker in partial_reduce_members:
            if self.bw[src_worker-1][dst_worker-1]!=0: # link is OK
                link=links[dst_worker-1]
                # broadcast 的 newflow 和 reduce 的 newflow 不太一样, 少了 'TRAIN' 和 'SYNC', 但是不重要
                new_flow={}
                new_flow['aggregated_worker']=src_worker   # 表示这个分块是哪个 worker 聚合的
                new_flow['p_id']=p_id
                new_flow['left_size']=block_size
                new_flow['total_size']=block_size
                new_flow['flow_type']='BCAST'
                new_flow['b_id']=b_id

                # assert len(link) in [0,1]
                # if len(link)==1:
                #     assert link[0]['flow_type']=='REDUCE'
                
                # link.insert(0,new_flow)


                link.append(new_flow)
                
                # LOGGER.debug('Time {0} src = {1} dst = {2} pid {3} type {4} left_size {5} total_size {6}'.format(cur_time,src_worker,dst_worker,new_flow['p_id'],new_flow['flow_type'],new_flow['left_size'],new_flow['total_size'],new_flow['total_size']))
            
            else:  #  link 故障
                backup_worker=self.controller.failure_recovery_bcast(p_id,src_worker,dst_worker,b_id,block_size,src_worker)
                # LOGGER.info('Time {0} link {1} ---> {2} FAIL BCAST p-id {3} b-id {4} forward backup_worker {5}'.format(self.get_cur_time(),src_worker,dst_worker,p_id,b_id,backup_worker))



        
        assert self.flow_last_update_time==cur_time
        # check_active_flows() already make them equal, but the meanings are different
        # check_active_flows() makes the exist flows update to cur_time
        # add_bcast_flows() set the new bcast flows time to cur_time
        self.flow_last_update_time=cur_time

        return events
    
    # (self.id,dst_worker,chunk_size,block_id,worker_status)
    def add_single_reduce_flow(self,src_worker,dst_worker,chunk_size,block_id,worker_status):

        events=[]
        # check the flows first
        events.extend(self.check_active_flows())  # 凡是往网络中修改网络流的操作, 都应该将网络流状态更新到当前
        cur_time=self.get_cur_time()

        '''
            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            
        '''
        # worker_status={'TRAIN':self.train_round_cnt,'SYNC':self.sync_round_cnt,'SRC':self.id,'p_id':self.cur_partial_reduce_id}
        
        retransmit_flow=deepcopy(worker_status)
        retransmit_flow['left_size']=chunk_size
        retransmit_flow['total_size']=chunk_size
        retransmit_flow['flow_type']='REDUCE-RECOVERY'
        retransmit_flow['b_id']=block_id  # 从 1 开始
        
        link=self.links[src_worker-1][dst_worker-1]  # src 和 dst 都是从 1 开始
        link.append(retransmit_flow)

        assert self.flow_last_update_time==cur_time
        # check_active_flows() already make them equal, but the meanings are different
        # check_active_flows() makes the exist flows update to cur_time
        # add_reduce_flows() set the new flows time to cur_time
        self.flow_last_update_time=cur_time
       
        # LOGGER.info('Time {0} src_worker {1} add REDUCE-RECOVERY flow dst_worker {2} p-id {3} b-id {4}'.format(cur_time,src_worker,dst_worker,worker_status['p_id'],block_id))
        return events 


    # (self.id,dst_worker,chunk_size,block_id,worker_status)
    def add_single_reduce_complement_flow(self,src_worker,dst_worker,left_size,total_size,block_id):

        events=[]
        # check the flows first
        events.extend(self.check_active_flows())  # 凡是往网络中修改网络流的操作, 都应该将网络流状态更新到当前
        cur_time=self.get_cur_time()

        '''
            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            
        '''
        # worker_status={'TRAIN':self.train_round_cnt,'SYNC':self.sync_round_cnt,'SRC':self.id,'p_id':self.cur_partial_reduce_id}
        worker_status={'TRAIN':self.workers[src_worker].train_round_cnt,'SYNC':self.workers[src_worker].sync_round_cnt,'SRC':self.workers[src_worker].id,'p_id':self.workers[src_worker].cur_partial_reduce_id}
        retransmit_flow=deepcopy(worker_status)
        retransmit_flow['left_size']=left_size
        retransmit_flow['total_size']=total_size
        retransmit_flow['flow_type']='REDUCE-COMPLEMENT'
        retransmit_flow['b_id']=block_id  # 从 1 开始
        
        link=self.links[src_worker-1][dst_worker-1]  # src 和 dst 都是从 1 开始
        link.append(retransmit_flow)

        assert self.flow_last_update_time==cur_time
        # check_active_flows() already make them equal, but the meanings are different
        # check_active_flows() makes the exist flows update to cur_time
        # add_reduce_flows() set the new flows time to cur_time
        self.flow_last_update_time=cur_time
       
        # LOGGER.info('Time {0} src_worker {1} add REDUCE-COMPLEMENT flow dst_worker {2} p-id {3} b-id {4} left_size {5} total_size {6}'.format(cur_time,src_worker,dst_worker,worker_status['p_id'],block_id,retransmit_flow['left_size'],retransmit_flow['total_size']))
        return events 

    def add_single_bcast_flow(self,src_worker,dst_worker,p_id,b_id,block_size,aggregated_worker):
        events=[]
        # check the flows first
        events.extend(self.check_active_flows())  # 凡是往网络中修改网络流的操作, 都应该将网络流状态更新到当前
        cur_time=self.get_cur_time()

        '''
            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            
        '''
        # worker_status={'TRAIN':self.train_round_cnt,'SYNC':self.sync_round_cnt,'SRC':self.id,'p_id':self.cur_partial_reduce_id}
        
        forward_flow={}
        forward_flow['SRC']=src_worker
        forward_flow['p_id']=p_id
        forward_flow['left_size']=block_size
        forward_flow['total_size']=block_size
        forward_flow['flow_type']='BCAST-FORWARD'
        forward_flow['aggregated_worker']=aggregated_worker
        forward_flow['b_id']=b_id  # 从 1 开始
        
        link=self.links[src_worker-1][dst_worker-1]  # src 和 dst 都是从 1 开始
        link.append(forward_flow)
        
        # LOGGER.info('Time {0} src_worker {1} add BCAST-FORWARD flow dst_worker {2} p-id {3} b-id {4}'.format(cur_time,src_worker,dst_worker,p_id,b_id))
        assert self.flow_last_update_time==cur_time
        # check_active_flows() already make them equal, but the meanings are different
        # check_active_flows() makes the exist flows update to cur_time
        # add_reduce_flows() set the new flows time to cur_time
        self.flow_last_update_time=cur_time
        
        return events          

    def link_failure_recovery(self,worker_a,worker_b):
        # 注意 worker_a, worker_b 从 1 开始编号


        '''
            修改了流结构, 比 FMReduce 复杂     worker 在发送流的时候, 要符合现在的格式, 还有 net  process   check_active_flows 的时候, 也要匹配现在的流格式  代码检查
            partial reduce id 和 block id 都是从 1 开始
            self.links=
            [
                [ [ {'left_size':70, 'total_size':80, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'BCAST','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}, {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [ {'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4} ], [{'left_size':70, 'flow_type':'REDUCE','TRAIN':2,'SYNC':2,'p_id':12,'b_id':4}] ] , 
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
                [ [], [], [], [], [] ],
            ]
            flows[i][j] means the src=i+1--->dst=j+1 flows
        '''
        events=[]
        # 分别检查 a->b 和 b->a 的流
        for link in [[worker_a,worker_b],[worker_b,worker_a]]:
            
            src_worker=link[0]
            dst_worker=link[1]
            link=self.links[src_worker-1][dst_worker-1]
            for flow in link:
                flow_type=flow['flow_type']
                p_id=flow['p_id']
                block_id=flow['b_id']
                block_size=flow['total_size']
                # 之前的代码务必保证同一组 p 中的 worker 的模型划分一致
                if p_id==-1:
                    continue
                # 首先处理 REDUCE 流
                if flow_type.split('-')[0]=='REDUCE':  # 如果一个 REDUCE 流还没有分配到某个 partial reduce 组中, 不需要为它考虑重传, 因为重传需要整个 partial reduce 组中成员协调
                    backup_worker=self.controller.failure_recovery_reduce(p_id,dst_worker,block_id,block_size)    
                    # LOGGER.info('Time {0} link {1} ---> {2} FAIL REDUCE p-id {3} b-id {4} aggregated backup_worker {5}'.format(self.get_cur_time(),src_worker,dst_worker,p_id,block_id,backup_worker))
                    
                    
                else: # BCAST
                    backup_worker=self.controller.failure_recovery_bcast(p_id,src_worker,dst_worker,block_id,block_size,flow['aggregated_worker'])
                    # LOGGER.info('Time {0} link {1} ---> {2} FAIL BCAST p-id {3} b-id {4} forward backup_worker {5}'.format(self.get_cur_time(),src_worker,dst_worker,p_id,block_id,backup_worker))

        return events




class Environment(object):
    def __init__(self, net, workers,controller):
        self.events = []
        self.cur_time = 0.0

        self.net = net
        self.workers = workers
        self.controller=controller
        self.elements = [self.net, ]
        self.elements.extend(self.workers)
 

        # elements = [net, w1, w2, w3, w4]

        self.init_elements()

    def add_events(self, events):
        for e in events:
            heapq.heappush(self.events, e)

    def init_elements(self):
        for o in self.elements:
            o.register_env(self)
            # print(o.TYPE)
            # print(getattr(o,'id','sorry'))
            # input('pause')
            self.add_events(o.start())

    def stop_elements(self):
        for term in self.elements:
            self.add_events(term.stop())

    def get_cur_time(self):
        return self.cur_time
    
    def check_EnvObj_stop(self):
        # update net status to cur_time
        self.net.check_active_flows()

        stopped_workers=[]
        # check workers 
        for w in self.workers:
            # LOGGER.info('worker {0} STATE {1} TRAIN {2} SYNC {3}'.format(w.id,w.state,w.train_round_cnt,w.sync_round_cnt))
            # LOGGER.info('worker {0} Detail INFO ===> reduce buffer {1} bcast buffer {2} aggregate queue {3}'.format(w.id,w.full_time_aggregated_blocks,w.arrival_aggregated_blocks,w.p_reduce_aggregate_group))
            if w.state!=Worker.STOPPED:
                w.stop()
            else:
                stopped_workers.append(w.id)
        
        # LOGGER.info('normally terminate workers {0}'.format(stopped_workers))


        '''
        flows_table=
        [
            [ [], [], [], [], [] ],
            [ [], [], [], [], [] ],
            [ [], [], [], [], [] ],
            [ [], [], [], [], [] ],
            [ [], [], [], [], [] ]
        ]        
        '''


        # for i in range(len(self.net.flows)):
        #     LOGGER.info(self.net.flows[i])

        self.net.stop()
    

    # 
    def save_result(self,end_time,filedir):
        net_mode=self.net.net_mode
        model_split=self.net.model_split
        block=self.net.workers[1].block
        worker_num=self.net.worker_num
        p=self.workers[0].REDUCE_P
        
        train_rounds=np.zeros((worker_num),dtype=np.int_)      
        sync_rounds=np.zeros((worker_num),dtype=np.int_)
        
        for w in self.workers:
            id=w.id
            train_rounds[id-1]=w.train_round_cnt
            sync_rounds[id-1]=w.sync_round_cnt
        
        sync_rounds_sum=sync_rounds.sum()
        train_rounds_sum=train_rounds.sum()

        avg_train_cnt=train_rounds_sum/worker_num
        avg_sync_cnt=sync_rounds_sum/worker_num


        # id=GET_ID('./results/')


        file_dir=filedir+'n='+str(worker_num)+',sd='+str(self.net.straggler_distribution)+',bwd='+str(self.net.bandwidth_distribution)+'/p='+str(p)+'/'
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        # now = time.strftime("%Y_%m%d_%H%M_%S", time.localtime(time.time()))  # 获得当前时间 2021_1108_2310_22
        
        filename='netmode='+net_mode+',model_split='+model_split+',block='+str(block)+',imp='+str(self.controller.imp_non_blocking)+'.txt'
        with open(file_dir+filename,'a') as f:
            f.write(str(avg_sync_cnt)+'\t')
            f.write(str(avg_train_cnt)+'\t')
            # f.write(str(self.controller.partial_reduce_cnt))
            f.write(str(worker_num)+'\t')
            f.write(str(p)+'\t')
            f.write(str(end_time)+'\t')
            f.write(str(list(train_rounds))+'\t')
            f.write(str(list(sync_rounds))+'\t')
            f.write(str(train_rounds_sum)+'\t')
            f.write(str(sync_rounds_sum)+'\t')
            f.write('\n')
            # f.write(str(self.controller.partial_reduce_cnt))
            # f.write('\n')
        
        # filename_bw='n='+str(worker_num)+',p='+str(p)+'_net'+'.txt'
        # with open(file_dir+filename_bw,'a') as f:
        #     for row in self.net.bw:
        #         f.write(str(list(row))+'\n')
        #     f.write('\n')


    def run(self, end_time=None,filedir=''):
        
        while end_time is None or self.cur_time < end_time:
            if len(self.events) == 0:
                break
            e = heapq.heappop(self.events)

            assert e.t >= self.cur_time
            self.cur_time = e.t
           
            new_events = e.exec()
            

            for e in new_events:
                heapq.heappush(self.events, e)
            
        self.check_EnvObj_stop()
        self.save_result(end_time,filedir)

# (WorkerNum,straggler_distribution,bandwidth_distribution,trial_round,p,EndTime,netmode,modelsplit,BLOCK,filedir)
def start_simulate(WorkerNum=6,STRAGGLER_DISTRIBUTION=1,BANDWIDTH_DISTRIBUTION=1,TRIAL_ROUND=1,REDUCE_P=3,EndTime=10,netmode='FIFO',modelsplit='network-aware',is_block=False,imp_non_blocking=True,filedir=''):

    worker_num = WorkerNum
    
    model_size_KB=BASE_CHUNK_SIZE_KB*worker_num  # make every chunk has a centain size, not too small

    # model_size_KB = 1e4
    # grad_size_KB = 1e4
 
    end_time=EndTime

    # (self,worker_num=10,straggler_distribution=1,bandwidth_distribution=1,trial_round=1, time_step=1e-3,net_mode='FIFO',model_split='network-aware', bw_kbps=1e6,model_size_KB=1e3):
    net = OBSNET(worker_num=worker_num,straggler_distribution=STRAGGLER_DISTRIBUTION,bandwidth_distribution=BANDWIDTH_DISTRIBUTION,trial_round=TRIAL_ROUND, time_step=1e-3,net_mode=netmode,model_split=modelsplit,bw_kbps=1e6,model_size_KB=model_size_KB)
    
    # 必须先初始化 net, 再初始化  controller
    
    controller = Controller(net=net,REDUCE_P=REDUCE_P,IMP_NON_BLOCKING=imp_non_blocking)

    workers = []
    for _ in range(worker_num):
        
        w = Worker(net,controller,worker_num,STRAGGLER_DISTRIBUTION,BANDWIDTH_DISTRIBUTION,TRIAL_ROUND,REDUCE_P, model_size_KB=model_size_KB,block=is_block,imp_non_blocking=imp_non_blocking)
        workers.append(w)

    env = Environment(net, workers,controller)

    env.run(end_time=end_time,filedir=filedir)

    print('WorkerNum {0} P {1} EndTime {2} NETMODE {3} MODELSPLIT {4} BLOCK {5} IMP {6} complete !!!'.format(WorkerNum,REDUCE_P,EndTime,netmode,modelsplit,is_block,imp_non_blocking))
    # LOGGER.info('WorkerNum {0} EndTime {1} BWDivide {2} MODELDivide {3} complete !!!'.format(WorkerNum,EndTime,BWDivide,MODELDivide))
    Worker._next_id=1
    OBSNET._next_id=1


def test_FCFS(): 


    workernum_list=[60]
    straggler_distribution_list=[1,2]
    bandwidth_distribution_list=[1,2]
    # trial_round_list=[1,2,3]  0728测试了3组
    # trial_round_list=[4,5,6]   #0729又测试3组
    # trial_round_list=[7,8,9,10]  # 0731-0133 又跑4组
    trial_round_list=[11,12,13,14,15,16,17,18,19,20]  # 20230329-0242 又跑10组


    filedir='./NoFail_FCFS/'  #+'result_'+str(id)+'/'
    now = time.strftime("%Y_%m%d_%H%M_%S", time.localtime(time.time()))  # 2022_0724_1241_44
    filedir=filedir+now+'/'  # ./test-1/2022_0724_1241_44/

    if not os.path.exists(filedir):
        os.makedirs(filedir)


    EndTime=50
    
    
    for straggler_distribution in straggler_distribution_list:
        for bandwidth_distribution in bandwidth_distribution_list:
            for WorkerNum in workernum_list:     
                for p in [4,5,10,12]:
                    for netmode in ['FIFO']:
                        for modelsplit in ['network-aware']:
                            for is_block in [True]:
                                for imp_non_blocking in [False]:
                                    for trial_round in trial_round_list:
                                        generate_input_file(WorkerNum,straggler_distribution,bandwidth_distribution,trial_round)
                                        start_simulate(WorkerNum,straggler_distribution,bandwidth_distribution,trial_round,p,EndTime,netmode,modelsplit,is_block,imp_non_blocking,filedir)

    print('done!')



if __name__ == '__main__':


                
    test_FCFS()
